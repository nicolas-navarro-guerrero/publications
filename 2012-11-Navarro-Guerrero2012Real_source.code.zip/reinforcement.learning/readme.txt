How to read the LEARNING STATS IN COMPACT FORMAT TO FILE:
1st Column = current trial number
2nd Column = total trial number
3rd Column = total number of steps/actions executed in the current trial
4th Column = Total number of states
5th Column = number of states visited so far (extracted from weights information)
|
6th Column = action number
7th Column = number of weights learned by action of previous column
8th Column = percentage of weights learned by action of previous column

6th to 8th Column repeats for the number of actions


IF YOU HAVE TELEOPERATED EXAMPLES USE GAUSSIAN ACTIVATION STATES FOR OFF-LINE TRAINING.

IF THE TRAINING EXAMPLES ARE GENERATED AUTOMATICALL JUST USE OFF-LINE TRAINING WITH SINGLE STATE ACTIVATION
