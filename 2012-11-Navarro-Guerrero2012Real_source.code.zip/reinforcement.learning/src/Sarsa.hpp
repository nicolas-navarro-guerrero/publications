//*****************************************************************************
// Title: sarsa.hpp
//
// Version: 0.12
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: February 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

#ifndef __SARSA_H__
#define __SARSA_H__

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <ctime>
//-----------------------------------------------------------------------------
// Specific tool libraries

//-----------------------------------------------------------------------------
// Own Libraries
#include "Verbosity.hpp"
#include "World.hpp"
#include "RandomNumberGenerators.hpp"

//*****************************************************************************
// Global Variables Definition
using namespace std;

const string default_weights_file_name = "weights.txt";
const string default_weights_stats_file_name = "weights-stats.txt";
const string default_stats_file_name = "learning-stats.txt";
const string default_compact_stats_file_name = "compact-learning-stats.txt";

enum _WEIGHTS_SOURCE_ {
  _SET_WEIGHTS_TO_ZERO = 0,
  _GENERATE_RANDOM_WEIGHTS,
  _KEEP_WEIGHTS_FROM_PREVIOUS_ITERATION,
  _WEIGHTS_FROM_FILE,
  _UPDATE_WEIGHTS
};

//*****************************************************************************
/**
 * SARSA Class Declaration
 */
//*****************************************************************************
class Sarsa {
  public:
    Sarsa();
    ~Sarsa();

    World* world;
    void sarsaAlgorithm(unsigned int trials);
  /**
   * setLearningParameters(vector<double> values);
   * Set learning parameters listed as follow: learning rate (epsilon),
   * Discount factor (gamma) and Reliability for action (beta)
   */
    void setLearningParameters(vector<double> values);
    void setLearningParameter_exploitation(double values);
    void setLearningParameter_discountFactor(double values);
    void setLearningParameter_learningRate(double values);

    void setWeightsSourceTo(char value);
    void enableWeightUpdate(void);
    void disableWeightUpdate(void);

    void setVerbosity(unsigned int value);
    bool loadWeightsFromFile(void);
    void exportWeightsToFile(void);
    void exportStatsToFile(unsigned int _currentTrial, unsigned int _expectedTrials, unsigned int _actions);
    void exportCompactStatsFormatToFile(vector<unsigned int> trialInfo, vector<unsigned int> actionInfo);
    void exportCompactStatsFormatToFile(unsigned int _currentTrial, unsigned int _expectedTrials, unsigned int _actions);
    vector<vector<double> > getWeightsValues(void);

    // This functions should only be in the World class file
    void setActionsAndStatesNumber(unsigned int A, unsigned int S);
    void setGoalState(unsigned int value);
    void setGoalState(unsigned int x, unsigned int y);
    void setActionSelectionMode(char value);
    void setStateActivationMode(char value);
    void setStateActivationMode(char value, unsigned int size);
    void exportWeightsToImages(void);
    void exportWeightsToImages(string prefix);
    void setOperationMode(char value);
    double getPercentageVisitedStates(void);

  protected:

  private:
    void init(void);
    void printProgramVersion(void);
    RandomNumberGenerators RNG;

    vector<double> computeOutputStrength(vector<double> s_values);
    unsigned int selectAction(vector<double> outputStrength);
    // Compute Qsa
    double computeCurrentEstimate(unsigned int Ai, vector<double> s_values);
    // Compute delta
    double computePredictionError(double QPrime, double Q, double reward);
    void updateWeights(unsigned int Ai, vector<double> s_values, double delta);

    double epsilon;
    double gamma;
    double beta;
    vector<vector<double> > weights;
    vector<double> max_w;
    vector<double> min_w;
    unsigned int statesNum;
    unsigned int actionsNum;
    unsigned int verbosity;
    char actionSelectionMode;
    char weightsSource;
    char weightsUpdate;
};
//*****************************************************************************
// SARSA Class Declaration: END
//*****************************************************************************

#endif  // __SARSA_H__
