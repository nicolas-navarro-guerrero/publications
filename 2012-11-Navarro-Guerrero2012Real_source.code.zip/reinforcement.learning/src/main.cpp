//*****************************************************************************
// Title: main.cpp
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: August 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: August 2011
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries
#include <cstdio>
//-----------------------------------------------------------------------------
// Own Libraries
#include "./Sarsa.hpp"
#include "./Authorship.hpp"

//*****************************************************************************
// Global Variables Definition
const int states_num = 25*25;
const int trialsnumber = 10*9;
const int reward_x_coord = 12;//4;
const int reward_y_coord = 24;//8;

//*****************************************************************************
// Global Function Definition
void randomExplorationWithSARSA(void);
void randomExplorationWithGaussian(void);
void self_supervisedSARSA(void);
void self_supervisedGAUSSIAN(void);
void batch_single(void);
void batch_gaussian(void);
void test_trained_network_single(void);
void test_trained_network_gaussian(void);
void userGuidedActions(void);

void load_and_plot_weights_forward_docking(void);

//*****************************************************************************
// MAIN FUNCTION BEGIN
//*****************************************************************************
int main(int argc, char *argv[]) {
  printProgramVersion();

for (unsigned int idr = 0; idr < 10; idr++) {
    randomExplorationWithSARSA();
}

//for (unsigned int idr = 0; idr < 10; idr++) {
//    randomExplorationWithGaussian();
//}

//  self_supervisedSARSA();

//  batch_single();
//for (unsigned int idr = 0; idr < 10; idr++) {
//    test_trained_network_single();
//}


//  batch_gaussian();
//for (unsigned int idr = 0; idr < 10; idr++) {
//    test_trained_network_gaussian();
//}

//  load_and_plot_weights_forward_docking();

//    userGuidedActions();

  return(0);
}
//*****************************************************************************
// MAIN FUNCTION END
//*****************************************************************************

//*****************************************************************************
//*****************************************************************************
void randomExplorationWithSARSA(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(500);
  navigation.setWeightsSourceTo(_SET_WEIGHTS_TO_ZERO);
  navigation.disableWeightUpdate();
  navigation.setActionSelectionMode(_SOFTMAX);
  navigation.setStateActivationMode(_SINGLE_STATE_ACTIVATION);
  navigation.setOperationMode(_RANDOM_EXPLORATION);

  navigation.sarsaAlgorithm(10);
//  navigation.exportWeightsToImages("randomExplorationWithSarsa");
}
//*****************************************************************************
//*****************************************************************************
void randomExplorationWithGaussian(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(5);
  navigation.setWeightsSourceTo(_SET_WEIGHTS_TO_ZERO);
  navigation.setActionSelectionMode(_SOFTMAX);
  navigation.setStateActivationMode(_GAUSSIAN_STATE_ACTIVATION);

  navigation.sarsaAlgorithm(10);
//  navigation.exportWeightsToImages("randomExplorationWithGaussian");
}
//*****************************************************************************
//*****************************************************************************
void self_supervisedSARSA(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(20);
  navigation.setWeightsSourceTo(_SET_WEIGHTS_TO_ZERO);
  navigation.setActionSelectionMode(_HARD_CODED_POLICY);
  navigation.setStateActivationMode(_SINGLE_STATE_ACTIVATION);

  navigation.sarsaAlgorithm(10);
  navigation.exportWeightsToImages("self_supervisedSARSA");
}
//*****************************************************************************
//*****************************************************************************
void batch_single(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(20);
  navigation.setWeightsSourceTo(_SET_WEIGHTS_TO_ZERO);
  navigation.setActionSelectionMode(_ACTIONS_FROM_FILE);
  navigation.setStateActivationMode(_SINGLE_STATE_ACTIVATION);
  navigation.setOperationMode(_BATCH);

  int iterations = 0;
  double percentageVisitedStates_t1 = 0;
  double percentageVisitedStates_t0 = 0;
  do {
    percentageVisitedStates_t0 = percentageVisitedStates_t1;
    navigation.sarsaAlgorithm(20);
    percentageVisitedStates_t1 = navigation.getPercentageVisitedStates();
    iterations++;
  } while ((iterations < 25) && (percentageVisitedStates_t0 != percentageVisitedStates_t1));

  navigation.exportWeightsToImages("batch-single");
}
//*****************************************************************************
//*****************************************************************************
void batch_gaussian(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(20);
  navigation.setWeightsSourceTo(_SET_WEIGHTS_TO_ZERO);
  navigation.setActionSelectionMode(_ACTIONS_FROM_FILE);
  navigation.setStateActivationMode(_GAUSSIAN_STATE_ACTIVATION);
  navigation.setOperationMode(_BATCH);
  navigation.sarsaAlgorithm(1000);

  navigation.exportWeightsToImages("batch-gaussian");
}
//*****************************************************************************
//*****************************************************************************
void test_trained_network_single(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(500);
  navigation.setWeightsSourceTo(_WEIGHTS_FROM_FILE);
  navigation.disableWeightUpdate();
  navigation.setActionSelectionMode(_SOFTMAX);
  navigation.setStateActivationMode(_SINGLE_STATE_ACTIVATION);
  navigation.setOperationMode(_RANDOM_EXPLORATION);
  navigation.sarsaAlgorithm(10);

//  navigation.exportWeightsToImages("tested-100");
}
//*****************************************************************************
//*****************************************************************************
void test_trained_network_gaussian(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(500);
  navigation.setWeightsSourceTo(_WEIGHTS_FROM_FILE);
  navigation.disableWeightUpdate();
  navigation.setActionSelectionMode(_SOFTMAX);
  navigation.setStateActivationMode(_GAUSSIAN_STATE_ACTIVATION);
  navigation.setOperationMode(_RANDOM_EXPLORATION);
  navigation.sarsaAlgorithm(10);

//  navigation.exportWeightsToImages("tested-100");
}
//*****************************************************************************
//*****************************************************************************
void load_and_plot_weights_forward_docking(void) {
  Sarsa navigation;
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setWeightsSourceTo(_WEIGHTS_FROM_FILE);
  vector<vector<double> > weights;
  weights = navigation.getWeightsValues();
  navigation.world->exportWeightsToImages_3substates(weights, "forward-docking");
}

//*****************************************************************************
//*****************************************************************************
void userGuidedActions(void) {
  Sarsa navigation;
  navigation.setActionsAndStatesNumber(4, states_num);
  navigation.setVerbosity(VERBOSITY_LOW);
  navigation.setGoalState(reward_x_coord, reward_y_coord);
  navigation.setLearningParameter_exploitation(20);
  navigation.setWeightsSourceTo(_SET_WEIGHTS_TO_ZERO);
  navigation.disableWeightUpdate();
  navigation.setActionSelectionMode(_USER_GENERATED);
  navigation.setStateActivationMode(_SINGLE_STATE_ACTIVATION);

  navigation.sarsaAlgorithm(1);
//  navigation.exportWeightsToImages("randomExplorationWithSarsa");
}
