//*****************************************************************************
// Title: RandomNumberGenerators.hpp
// Description: random number generator
//  Based on Agner Fog work. For more information and a complete documentation
//  of this library visit: http://www.agner.org/random
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: October 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: November 2011
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

#ifndef __RANDOM_NUMBER_GENERATORS_LIBRARY_H__
#define __RANDOM_NUMBER_GENERATORS_LIBRARY_H__

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries
#include <cstdio>
#include <cstdlib>
//#include <stdint.h>
#include <cmath>
#include <vector>
#include <ctime>
//-----------------------------------------------------------------------------
// Specific tool libraries

//-----------------------------------------------------------------------------
// Own Libraries
//#include "Verbosity.hpp"

//*****************************************************************************
// Global Variables Definition
using namespace std;

typedef signed int          int32_t;
typedef unsigned int       uint32_t;
typedef long long           int64_t;
typedef unsigned long long uint64_t;

enum _RANDOM_NUMBER_GENERATORS_METHOD_ {
  _RNG_STANDARD = 0,
  _RNG_MERSENNE_TWISTER,
  _RNG_MOTHER_OF_ALL
};

// Constants for type MT19937:
const unsigned long int MERS_N = 624;
const unsigned long int MERS_M = 397;
const unsigned long int MERS_R = 31;
const unsigned long int MERS_U = 11;
const unsigned long int MERS_S = 7;
const unsigned long int MERS_T = 15;
const unsigned long int MERS_L = 18;
const unsigned long int MERS_A = 0x9908B0DF;
const unsigned long int MERS_B = 0x9D2C5680;
const unsigned long int MERS_C = 0xEFC60000;

//*****************************************************************************
/**
 * RNG = RANDOM NUMBER GENERATORS Class Declaration
 */
//*****************************************************************************
class RandomNumberGenerators {
  public:
    RandomNumberGenerators();
    ~RandomNumberGenerators();

    // Uniformly distributed pseudorandom numbers
    double randd(void);
    vector<vector<double> > randd(unsigned int n);
    vector<vector<double> > randd(unsigned int m, unsigned int n);

    // Sparse uniformly distributed random matrix (0 <= density <= 1)
    vector<vector<double> > sprand(unsigned int m, unsigned int n, double density);
    // Sparse normally distributed random matrix (0 <= density <= 1)
    vector<vector<double> > sprandn(unsigned int m, unsigned int n, double density);
    // Sparse symmetric random matrix. Returns a symmetric random, n-by-n,
    // sparse matrix with approximately density*n*n nonzeros. each entry is a
    // normally distributed random sample, and (0 <= density <= 1)
    vector<vector<double> > sprandsym(unsigned int n, double density);

    // Uniformly distributed pseudorandom integers
    int randi(unsigned int imax);
    vector<vector<int> > randi(unsigned int imax, unsigned int n);
    vector<vector<int> > randi(int imin, int imax, unsigned int n);
    vector<vector<int> > randi(unsigned int imax, unsigned int m, unsigned int n);
    vector<vector<int> > randi(int imin, int imax, unsigned int m, unsigned int n);


    void setSeed(unsigned long int value);
    void setRandomGeneratorMethod(char value);
    unsigned long int getSeed(void);
    char getRandomGeneratorMethod(void);

    bool randomBoolean(void);
  /**
   *  Generate 32 random bits */
    uint32_t randomWord(void);
  /** randomInteger(int min, int max);
   *  Gives an integer random number in the interval min <= x <= max.
   *  (max-min < MAXINT).
   *  The precision is 2^-32 (defined as the difference in frequency between
   *  possible output values). The frequencies are exact if max-min+1 is a
   *  power of 2.
   */
    int randomInteger(int min, int max);
  /** randomDouble();
   *  Gives a floating point random number in the interval 0 <= x < 1.
   *  The resolution is 32 bits in MOTHER_OF_ALL and MERSENNE_TWISTER METHODS,
   *  and 52 bits in SFMT METHOD.
   */
    double randomDouble(void);

  protected:

  private:
    void init(void);
    // Uniform random number generators
    void init_MERSENNE_TWISTER(uint32_t value);
    void init_MOTHER_OF_ALL(uint32_t value);


  /**
   *  Generate a random word, i.e. 32 random bits */
    uint32_t randomWord_STANDARD(void);
    uint32_t randomWord_MERSENNE_TWISTER(void);
    uint32_t randomWord_MOTHER_OF_ALL(void);

  /** double randomDouble_STANDARD(void);
   *  Pseudo-Random double in the range of [0, 1] with 9 digits of precision. */
    double randomDouble_STANDARD(void);
  /** double randomDouble_MERSENNE_TWISTER(void);
   *  Pseudo-Random double in the  range [0, 1[ with 32 bits of resolution */
    double randomDouble_MERSENNE_TWISTER(void);
  /** double randomDouble_MOTHER_OF_ALL(void);
   *  Pseudo-Random double in the  range [0, 1[ with 32 bits of resolution */
    double randomDouble_MOTHER_OF_ALL(void);

    int randomInteger_STANDARD(int min, int max);
  /**
   *  Pseudo-Random Integer in the interval min <= x <= max. (max-min < MAXINT)
   *  The precision is 2^-32 (defined as the difference in frequency between
   *  possible output values). The frequencies are exact if max-min+1 is a
   *  power of 2. */
    int randomInteger_MERSENNE_TWISTER(int min, int max);
  /**
   **/
    int randomInteger_MOTHER_OF_ALL(int min, int max);

    // Non-uniform random number generators

    unsigned long int myseed;
    char _RNG_METHOD_;

    // MERSENNE_TWISTER Variables
    unsigned long int mt[MERS_N];   // State vector
    unsigned int mti;               // Index into mt
    unsigned long int LastInterval; // Last interval length for IRandomX
    unsigned long int RLimit;       // Rejection limit used by IRandomX
    // MOTHER_OF_ALL Variables
    uint32_t MOAState[5];           // State vector for Mother-Of-All generator
};
//*****************************************************************************
// RNG = RANDOM NUMBER GENERATORS Class Declaration: END
//*****************************************************************************

#endif  // __RANDOM_NUMBER_GENERATORS_LIBRARY_H__
