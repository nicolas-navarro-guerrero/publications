//*****************************************************************************
// Title: Normal.cpp
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: April 2012
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

//*****************************************************************************
// Libraries Declaration
#include "Normal.hpp"

//*****************************************************************************
// Global Variables Definition


//*****************************************************************************
// normal_distribution Class Implementation: BEGIN
//*****************************************************************************
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
normal_distribution::normal_distribution() {
  init();
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
normal_distribution::~normal_distribution() {
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void normal_distribution::init(void) {
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<vector<vector<double> > > normal_distribution::sphericalGaussianDistribution(vector<double> _x, vector<double> _y, vector<double> _z, double sigma) {
  vector<vector<vector<double> > > retvalue;
	vector<double> tmp_vector;
	vector<vector<double> > tmp_matrix;
  tmp_vector.assign(lrint(_x[__SAMPLES]), 0.0);
	for(unsigned int i = 0; i < lrint(_y[__SAMPLES]); i++) {
		tmp_matrix.push_back(tmp_vector);
	}
	for(unsigned int i = 0; i < lrint(_z[__SAMPLES]); i++) {
		retvalue.push_back(tmp_matrix);
	}

  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor * factor;
  double exponent = 0.0;
  double x = _x[__FIRST_VALUE];
  double y = _y[__FIRST_VALUE];
  double z = _z[__FIRST_VALUE];

  for (unsigned int idt = 0; idt < lrint(_z[__SAMPLES]); idt++) {
  	for (unsigned int idr = 0; idr < lrint(_y[__SAMPLES]); idr++) {
  		for (unsigned int idc = 0; idc < lrint(_x[__SAMPLES]); idc++) {
        exponent = pow(x-_x[__MEAN],2) + pow(y-_y[__MEAN],2) + pow(z-_z[__MEAN],2);
        exponent = exponent/(2*sigma*sigma);
        retvalue[idt][idr][idc] = factor*exp(-exponent);
        x += _x[__RESOLUTION];
  		}
  		y += _y[__RESOLUTION];
  		x = _x[__FIRST_VALUE];
  	}
  	z += _z[__RESOLUTION];
  	y = _y[__FIRST_VALUE];
    x = _x[__FIRST_VALUE];
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<vector<vector<double> > > normal_distribution::sphericalGaussianDistribution(double ux, double uy, double uz, double sigma, double scope_minX, double scope_minY, double scope_minZ, unsigned int samples_x, unsigned int samples_y, unsigned int samples_z, double resolution_x, double resolution_y, double resolution_z) {
  vector<vector<vector<double> > > retvalue;
	vector<double> tmp_vector;
	vector<vector<double> > tmp_matrix;
  tmp_vector.assign(samples_x, 0.0);
	for(unsigned int i = 0; i < samples_y; i++) {
		tmp_matrix.push_back(tmp_vector);
	}
	for(unsigned int i = 0; i < samples_z; i++) {
		retvalue.push_back(tmp_matrix);
	}

  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor * factor;
  double exponent = 0.0;
  double x = scope_minX;
  double y = scope_minY;
  double z = scope_minZ;

  for (unsigned int idt = 0; idt < samples_z; idt++) {
  	for (unsigned int idr = 0; idr < samples_y; idr++) {
  		for (unsigned int idc = 0; idc < samples_x; idc++) {
        exponent = pow(x-ux,2) + pow(y-uy,2) + pow(z-uz,2);
        exponent = exponent/(2*sigma*sigma);
        retvalue[idt][idr][idc] = factor*exp(-exponent);
        x += resolution_x;
  		}
  		y += resolution_y;
  		x = scope_minX;
  	}
  	z += resolution_z;
  	y = scope_minY;
    x = scope_minX;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<vector<vector<double> > > normal_distribution::sphericalGaussianDistribution(double ux, double uy, double uz, double sigma, unsigned int samples_x, unsigned int samples_y, unsigned int samples_z, double resolution_x, double resolution_y, double resolution_z) {
  vector<vector<vector<double> > > retvalue;
	vector<double> tmp_vector;
	vector<vector<double> > tmp_matrix;
  tmp_vector.assign(samples_x, 0.0);
	for(unsigned int i = 0; i < samples_y; i++) {
		tmp_matrix.push_back(tmp_vector);
	}
	for(unsigned int i = 0; i < samples_z; i++) {
		retvalue.push_back(tmp_matrix);
	}

  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor * factor;
  double exponent = 0.0;
  double x = ux - (resolution_x*(samples_x/2));
  double y = uy - (resolution_y*(samples_y/2));
  double z = uz - (resolution_z*(samples_z/2));

  for (unsigned int idt = 0; idt < samples_z; idt++) {
  	for (unsigned int idr = 0; idr < samples_y; idr++) {
  		for (unsigned int idc = 0; idc < samples_x; idc++) {
        exponent = pow(x-ux,2) + pow(y-uy,2) + pow(z-uz,2);
        exponent = exponent/(2*sigma*sigma);
        retvalue[idt][idr][idc] = factor*exp(-exponent);
        x += resolution_x;
  		}
  		y += resolution_y;
  		x = ux - (resolution_x*(samples_x/2));
  	}
  	z += resolution_z;
  	y = uy - (resolution_y*(samples_y/2));
    x = ux - (resolution_x*(samples_x/2));
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<vector<vector<double> > > normal_distribution::sphericalGaussianDistribution(double ux, double uy, double uz, double sigma, unsigned int samples, double resolution) {
  vector<vector<vector<double> > > retvalue;
	vector<double> tmp_vector;
	vector<vector<double> > tmp_matrix;
  tmp_vector.assign(samples, 0.0);
	for(unsigned int i = 0; i < samples; i++) {
		tmp_matrix.push_back(tmp_vector);
	}
	for(unsigned int i = 0; i < samples; i++) {
		retvalue.push_back(tmp_matrix);
	}

  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor * factor;
  double exponent = 0.0;
  double x = ux - (resolution*(samples/2));
  double y = uy - (resolution*(samples/2));
  double z = uz - (resolution*(samples/2));

  for (unsigned int idt = 0; idt < samples; idt++) {
  	for (unsigned int idr = 0; idr < samples; idr++) {
  		for (unsigned int idc = 0; idc < samples; idc++) {
        exponent = pow(x-ux,2) + pow(y-uy,2) + pow(z-uz,2);
        exponent = exponent/(2*sigma*sigma);
        retvalue[idt][idr][idc] = factor*exp(-exponent);
        x += resolution;
  		}
  		y += resolution;
  		x = ux - (resolution*(samples/2));
  	}
  	z += resolution;
  	y = uy - (resolution*(samples/2));
    x = ux - (resolution*(samples/2));
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<vector<double> > normal_distribution::bivariateGaussianDistribution(vector<double> _x, vector<double> _y) {
  vector<vector<double> > retvalue;
	vector<double> tmp_vector;
  tmp_vector.assign(lrint(_x[__SAMPLES]), 0.0);
	for(unsigned int i = 0; i < lrint(_y[__SAMPLES]); i++) {
		retvalue.push_back(tmp_vector);
	}

  double factor = 1/(2*M_PI*_x[__SIGMA]*_y[__SIGMA]);
  double exponent = 0.0;
  double x = _x[__FIRST_VALUE];
  double y = _y[__FIRST_VALUE];
  for (unsigned int idr = 0; idr < lrint(_y[__SAMPLES]); idr++) {
  	for (unsigned int idc = 0; idc < lrint(_x[__SAMPLES]); idc++) {
      exponent = pow(x-_x[__MEAN],2)/(2*pow(_x[__SIGMA],2));
      exponent += pow(y-_y[__MEAN],2)/(2*pow(_y[__SIGMA],2));
      x += _x[__RESOLUTION];
      retvalue[idr][idc] = factor*exp(-exponent);
  	}
    y += _y[__RESOLUTION];
    x = _x[__FIRST_VALUE];
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Returns a vector of size samples containing the probability density function
// values of x using a normal distribution with mean ux and standard deviation
// sigma
// TODO: exploit symmetry to speed up computation
//-----------------------------------------------------------------------------
vector<vector<double> > normal_distribution::bivariateGaussianDistribution(double ux, double uy, double sigma_x, double sigma_y, double scope_minX, double scope_minY, unsigned int samples_x, unsigned int samples_y, double resolution_x, double resolution_y) {
  vector<vector<double> > retvalue;
	vector<double> tmp_vector;
  tmp_vector.assign(samples_x, 0.0);
	for(unsigned int i = 0; i < samples_y; i++) {
		retvalue.push_back(tmp_vector);
	}

  double factor = 1/(2*M_PI*sigma_x*sigma_y);
  double exponent = 0.0;
  double x = scope_minX;
  double y = scope_minY;
  for (unsigned int idr = 0; idr < samples_y; idr++) {
  	for (unsigned int idc = 0; idc < samples_x; idc++) {
      exponent = pow(x-ux,2)/(2*pow(sigma_x,2));
      exponent += pow(y-uy,2)/(2*pow(sigma_y,2));
      x += resolution_x;
      retvalue[idr][idc] = factor*exp(-exponent);
  	}
    y += resolution_y;
    x = scope_minX;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Returns a vector of size samples containing the probability density function
// values of x using a normal distribution with mean ux and standard deviation
// sigma
// TODO: exploit symmetry to speed up computation
//-----------------------------------------------------------------------------
vector<vector<double> > normal_distribution::bivariateGaussianDistribution(double ux, double uy, double sigma_x, double sigma_y, unsigned int samples_x, unsigned int samples_y, double resolution_x, double resolution_y) {
  vector<vector<double> > retvalue;
	vector<double> tmp_vector;
  tmp_vector.assign(samples_x, 0.0);
	for(unsigned int i = 0; i < samples_y; i++) {
		retvalue.push_back(tmp_vector);
	}

  double factor = 1/(2*M_PI*sigma_x*sigma_y);
  double exponent = 0.0;
  double x = ux - (resolution_x*(samples_x/2));
  double y = uy - (resolution_y*(samples_y/2));
  for (unsigned int idr = 0; idr < samples_y; idr++) {
  	for (unsigned int idc = 0; idc < samples_x; idc++) {
      exponent = pow(x-ux,2)/(2*pow(sigma_x,2));
      exponent += pow(y-uy,2)/(2*pow(sigma_y,2));
      x += resolution_x;
      retvalue[idr][idc] = factor*exp(-exponent);
  	}
    y += resolution_y;
    x = ux - (resolution_x*(samples_x/2));
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Returns a vector of size samples containing the probability density function
// values of x using a normal distribution with mean ux and standard deviation
// sigma
// TODO: exploit symmetry to speed up computation
//-----------------------------------------------------------------------------
vector<vector<double> > normal_distribution::bivariateGaussianDistribution(double ux, double uy, double sigma, unsigned int samples, double resolution) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor;
  double expDenominator = 2*pow(sigma,2);

  vector<vector<double> > retvalue;
	vector<double> tmp_vector;
  tmp_vector.assign(samples, 0.0);
	for(unsigned int i = 0; i < samples; i++) {
		retvalue.push_back(tmp_vector);
	}

  double exponent = 0.0;
  double x = ux - (resolution*(samples/2));
  double y = uy - (resolution*(samples/2));
  for (unsigned int idr = 0; idr < samples; idr++) {
  	for (unsigned int idc = 0; idc < samples; idc++) {
      exponent = pow(x-ux,2) + pow(y-uy,2);
      exponent /= expDenominator;
      x += resolution;
      retvalue[idr][idc] = factor*exp(-exponent);
  	}
    y += resolution;
    x = ux - (resolution*(samples/2));
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Returns a vector of size samples containing the probability density
// function values of x using a normal distribution with mean ux and standard
// deviation sigma. First value of x is given by scope
// TODO: exploit symmetry to speed up computation
//-----------------------------------------------------------------------------
vector<double> normal_distribution::gaussianDistribution(double ux, double sigma, double scope, unsigned int samples, double resolution) {
  double factor = 1/(sqrt(2*M_PI));
  double expDenominator = 2*pow(sigma,2);

  vector<double> retvalue(samples, 0.0);
  double exponent = 0.0;
  double x = scope;
  for (unsigned int idr = 0; idr < samples; idr++) {
    exponent = pow(x-ux,2) / expDenominator;
    x += resolution;
  	retvalue[idr] = factor*exp(-exponent);
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Returns a vector of size samples containing the probability density
// function values of x using a normal distribution with mean ux and standard
// deviation sigma
// TODO: exploit symmetry to speed up computation
//-----------------------------------------------------------------------------
vector<double> normal_distribution::gaussianDistribution(double ux, double sigma, unsigned int samples, double resolution) {
  double factor = 1/(sqrt(2*M_PI));
  double expDenominator = 2*pow(sigma,2);

  vector<double> retvalue(samples, 0.0);
  double exponent = 0.0;
  double x = ux - (resolution*(samples/2));
  for (unsigned int idr = 0; idr < samples; idr++) {
    exponent = pow(x-ux,2) / expDenominator;
    x += resolution;
  	retvalue[idr] = factor*exp(-exponent);
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of the uncorrelated variables x, y and z.
// With a mean value given by ux, uy and uz and a standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::sphericalGaussianFunction(double x, double ux, double y, double uy, double z, double uz, double sigma) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor * factor;
  double exp_num_sum = (x-ux)*(x-ux) + (y-uy)*(y-uy) + (z-uz)*(z-uz);
  double exponent = exp_num_sum/(2*sigma*sigma);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of the uncorrelated variables x, y and z.
// With a mean value given by ux, uy and uz and a standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::sphericalGaussianFunction(int x, int ux, int y, int uy, int z, int uz, double sigma) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor * factor;
  double exp_num_sum = (x-ux)*(x-ux) + (y-uy)*(y-uy) + (z-uz)*(z-uz);
  double exponent = exp_num_sum/(2*sigma*sigma);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of the uncorrelated variables x  and y. With a
// mean value given by ux and uy and a standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::bivariateGaussianFunction(double x, double ux, double y, double uy, double sigma_x, double sigma_y) {
  double factor = 1/(sigma_x*sigma_y*2*M_PI);
  double exponent = pow(x-ux,2)/(2*pow(sigma_x,2));
  exponent += pow(y-uy,2)/(2*pow(sigma_y,2));
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of the uncorrelated variables x  and y. With a
// mean value given by ux and uy and a standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::bivariateGaussianFunction(int x, int ux, int y, int uy, double sigma_x, double sigma_y) {
  double factor = 1/(sigma_x*sigma_y*2*M_PI);
  double exponent = pow(x-ux,2)/(2*pow(sigma_x,2));
  exponent += pow(y-uy,2)/(2*pow(sigma_y,2));
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of the uncorrelated variables x  and y. With a
// mean value given by ux and uy and a standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::bivariateGaussianFunction(double x, double ux, double y, double uy, double sigma) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor;
  double exponent = ((x-ux)*(x-ux) + (y-uy)*(y-uy))/(2*sigma*sigma);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of the uncorrelated variables x  and y. With a
// mean value given by ux and uy and a standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::bivariateGaussianFunction(int x, int ux, int y, int uy, double sigma) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  factor = factor * factor;
  double exponent = ((x-ux)*(x-ux) + (y-uy)*(y-uy))/(2*sigma*sigma);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of x using a normal distribution with mean ux
// and standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::gaussianFunction(double x, double ux, double sigma) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  double exponent = ((x-ux)*(x-ux)) / (2*sigma*sigma);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Return the probability value of x using a normal distribution with mean ux
// and standard deviation sigma
//-----------------------------------------------------------------------------
inline double normal_distribution::gaussianFunction(int x, int ux, double sigma) {
  double factor = 1/(sigma*sqrt(2*M_PI));
  double exponent = ((x-ux)*(x-ux)) / (2*sigma*sigma);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
inline double normal_distribution::standardNormalFunction(double x) {
  double factor = 1/(sqrt(2*M_PI));
  double exponent = (x*x) / (2);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
inline double normal_distribution::standardNormalFunction(int x) {
  double factor = 1/(sqrt(2*M_PI));
  double exponent = (x*x) / (2);
  double retvalue = factor*exp(-exponent);

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
inline vector<vector<double> > normal_distribution::normalize(vector<vector<double> > array) {
  unsigned int rows = array.size();
  unsigned int cols = array[0].size();
  double accumulator = 0.0;

  for (unsigned int idr = 0; idr < rows; idr++) {
  	for (unsigned int idc = 0; idc < cols; idc++) {
      accumulator += array[idr][idc];
  	}
  }

  for (unsigned int idr = 0; idr < rows; idr++) {
  	for (unsigned int idc = 0; idc < cols; idc++) {
      array[idr][idc] = array[idr][idc]/accumulator;
  	}
  }

  return(array);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
inline vector<double> normal_distribution::normalize(vector<double> array) {
  unsigned int rows = array.size();
  double accumulator = 0.0;

  for (unsigned int idr = 0; idr < rows; idr++) {
    accumulator += array[idr];
  }

  for (unsigned int idr = 0; idr < rows; idr++) {
    array[idr] = array[idr]/accumulator;
  }

  return(array);
}
//*****************************************************************************
// normal_distribution Class Implementation: BEGIN
//*****************************************************************************
