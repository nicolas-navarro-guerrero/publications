//*****************************************************************************
// Title: Normal.hpp
//
// Version: 0.1
// Copyright (C) 2012 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: April 2012
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

#ifndef __NORMAL_DISTRIBUTION_H__
#define __NORMAL_DISTRIBUTION_H__

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <ctime>

//-----------------------------------------------------------------------------
// Specific tool libraries

//-----------------------------------------------------------------------------
// Own Libraries

//*****************************************************************************
// Global Variables Definition
using namespace std;

const unsigned int __NUMBER_GAUSSIAN_PARAMETERS = 5;
enum __INDECES_PARAMETERS_GAUSSIAN_DISTRIBUTION {
  __MEAN = 0,
  __SAMPLES = 1,
  __RESOLUTION = 2,
  __FIRST_VALUE = 3,
  __SIGMA = 4
};

//*****************************************************************************
/**
 * normal_distribution Class Declaration
 */
//*****************************************************************************
class normal_distribution {
  public:
    normal_distribution();
    ~normal_distribution();

    // Returns a "parallelepiped" of size samples containing the Multivariate
    // Normal Distribution values of (x,y,z) with mean (ux,uy,uz) and
    // standard deviation sigma. First value of (x,y,z) are given by
    // (scope_minX,scope_minY,scope_minZ)
    vector<vector<vector<double> > > sphericalGaussianDistribution(vector<double> _x, vector<double> _y, vector<double> _z, double sigma);

    // Returns a "parallelepiped" of size samples containing the Multivariate
    // Normal Distribution values of (x,y,z) with mean (ux,uy,uz) and
    // standard deviation sigma. First value of (x,y,z) are given by
    // (scope_minX,scope_minY,scope_minZ)
    vector<vector<vector<double> > > sphericalGaussianDistribution(double ux, double uy, double uz, double sigma, double scope_minX, double scope_minY, double scope_minZ, unsigned int samples_x, unsigned int samples_y, unsigned int samples_z, double resolution_x, double resolution_y, double resolution_z);

    // Returns a "parallelepiped" of size samples containing the Multivariate
    // Normal Distribution values of (x,y,z) with mean (ux,uy,uz) and
    // standard deviation sigma.
    vector<vector<vector<double> > > sphericalGaussianDistribution(double ux, double uy, double uz, double sigma, unsigned int samples_x, unsigned int samples_y, unsigned int samples_z, double resolution_x, double resolution_y, double resolution_z);

    // Returns a "cube" of size samples containing the Multivariate Normal
    // Distribution values of (x,y,z) with mean (ux,uy,uz) and
    // standard deviation sigma.
    vector<vector<vector<double> > > sphericalGaussianDistribution(double ux, double uy, double uz, double sigma, unsigned int samples, double resolution);

    // Returns a vector of size samples containing the probability density
    // function values of x using a normal distribution with mean ux and standard
    // deviation sigma. Result is a elliptical Gaussian distribution in a
    // rectangular matrix. First value of (x,y) are given by
    // (scope_minX,scope_minY)
    vector<vector<double> > bivariateGaussianDistribution(vector<double> _x, vector<double> _y);

    // Returns a vector of size samples containing the probability density
    // function values of x using a normal distribution with mean ux and standard
    // deviation sigma. Result is a elliptical Gaussian distribution in a
    // rectangular matrix. First value of (x,y) are given by
    // (scope_minX,scope_minY)
    vector<vector<double> > bivariateGaussianDistribution(double ux, double uy, double sigma_x, double sigma_y, double scope_minX, double scope_minY, unsigned int samples_x, unsigned int samples_y, double resolution_x, double resolution_y);
    // Returns a vector of size samples containing the probability density
    // function values of x using a normal distribution with mean ux and standard
    // deviation sigma. Result is a elliptical Gaussian distribution centered
    // in a rectangular matrix
    vector<vector<double> > bivariateGaussianDistribution(double ux, double uy, double sigma_x, double sigma_y, unsigned int samples_x, unsigned int samples_y, double resolution_x, double resolution_y);

    // Returns a vector of size samples containing the probability density
    // function values of x using a normal distribution with mean ux and standard
    // deviation sigma. Result is a circular Gaussian distribution centered
    // in a square matrix
    vector<vector<double> > bivariateGaussianDistribution(double ux, double uy, double sigma, unsigned int samples, double resolution);

    // Returns a vector of size samples containing the probability density
    // function values of x using a normal distribution with mean ux and standard
    // deviation sigma.
    vector<double> gaussianDistribution(double ux, double sigma, unsigned int samples, double resolution);
    // Returns a vector of size samples containing the probability density
    // function values of x using a normal distribution with mean ux and standard
    // deviation sigma. First value of x is given by scope
    vector<double> gaussianDistribution(double ux, double sigma, double scope, unsigned int samples, double resolution);

    // Return the probability value of the uncorrelated variables x, y and z.
    // With a mean value given by ux, uy and uz and a standard deviation sigma
    double sphericalGaussianFunction(double x, double ux, double y, double uy, double z, double uz, double sigma);

    // Return the probability value of the uncorrelated variables x, y and z.
    // With a mean value given by ux, uy and uz and a standard deviation sigma
    double sphericalGaussianFunction(int x, int ux, int y, int uy, int z, int uz, double sigma);

    // Return the probability value of the uncorrelated variables x  and y. With
    // a mean value given by ux and uy and a standard deviation sigma
    double bivariateGaussianFunction(double x, double ux, double y, double uy, double sigma);
    double bivariateGaussianFunction(double x, double ux, double y, double uy, double sigma_x, double sigma_y);

    // Return the probability value of the uncorrelated variables x  and y. With a
    // mean value given by ux and uy and a standard deviation sigma
    double bivariateGaussianFunction(int x, int ux, int y, int uy, double sigma);
    double bivariateGaussianFunction(int x, int ux, int y, int uy, double sigma_x, double sigma_y);

    // Return the probability value of x using a normal distribution with mean ux
    // and standard deviation sigma
    double gaussianFunction(double x, double ux, double sigma);

    // Return the probability value of x using a normal distribution with mean ux
    // and standard deviation sigma
    /**
     * gaussianFunction(int x, int ux, double sigma)
     * Probability of x given a Gaussian distribution centered in ux and a
     * standard deviation sigma. Return a double value
     */
    double gaussianFunction(int x, int ux, double sigma);

    double standardNormalFunction(double x);

    double standardNormalFunction(int x);

    vector<vector<double> > normalize(vector<vector<double> > array);
    vector<double> normalize(vector<double> array);

  protected:

  private:
    void init(void);
    void printProgramVersion(void);
};
//*****************************************************************************
// normal_distribution Class Declaration: END
//*****************************************************************************

#endif  // __NORMAL_DISTRIBUTION_H__
