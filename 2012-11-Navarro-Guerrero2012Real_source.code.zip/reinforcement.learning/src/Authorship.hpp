//*****************************************************************************
// Title: Authorship.hpp
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: October 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: November 2011
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

#ifndef __AUTHORSHIP_H__
#define __AUTHORSHIP_H__

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries

//-----------------------------------------------------------------------------
// Specific tool libraries

//-----------------------------------------------------------------------------
// Own Libraries


//*****************************************************************************
// Global Variables Definition


//*****************************************************************************
//*****************************************************************************
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void printProgramVersion(void) {
  fprintf(stdout,
"*****************************************************************************"
"***\n");
  fprintf(stdout,
"Temporal Difference Learning - SARSA\n");
  fprintf(stdout,
"Program version: 0.2\n");
  fprintf(stdout,
"Copyright (C) 2011 Nicolas Navarro-Guerrero\n");
  fprintf(stdout,
"Contact: nicolas.navarro.guerrero@gmail.com\n");
  fprintf(stdout,
"Created in: October 2011\n");
  fprintf(stdout,
"Last Modification in: April 2012\n");
  fprintf(stdout,
"Last Modification by: Nicolas Navarro-Guerrero\n\n");

  fprintf(stdout,
"DISCLAIMER:\n"
"This program is distributed in the hope that it will be useful, but\n"
"WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU\n"
"General Public License for more details.\n\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program. If not, see http://www.gnu.org/licenses/.\n\n"
"Public License as published by the Free Software Foundation, either version 3\n"
"of the License, or (at your option) any later version.\n");

  fprintf(stdout,
"*****************************************************************************"
"***\n");
}

//*****************************************************************************
//*****************************************************************************

#endif  // __AUTHORSHIP_H__

