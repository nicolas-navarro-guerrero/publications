//*****************************************************************************
// Title: Sarsa.cpp
//
// Version: 0.2
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: February 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

//*****************************************************************************
// Libraries Declaration
#include "Sarsa.hpp"

//*****************************************************************************
// Global Variables Definition


//*****************************************************************************
// SARSA Class Implementation: BEGIN
//*****************************************************************************
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
Sarsa::Sarsa() {
  init();
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
Sarsa::~Sarsa() {
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::init(void) {
  verbosity = VERBOSITY_LOW;
  actionSelectionMode = _SOFTMAX;
  weightsSource = _SET_WEIGHTS_TO_ZERO;
  weightsUpdate = _UPDATE_WEIGHTS;

  epsilon = 0.5;  // Learning rate
  gamma = 0.8;    // Time-Discount factor
  beta = 70;     // Reliability for action

  actionsNum = 1;
  statesNum = 1;
  max_w.assign(actionsNum, 0);
  min_w.assign(actionsNum, 0);
  weights.clear();
	vector<double> tmp_w;
  tmp_w.assign(statesNum, 0);
	for(unsigned int idy = 0; idy < actionsNum; idy++) {
		weights.push_back(tmp_w);
	}
  world = new World();
  world->setActionsAndStatesNumber(actionsNum, statesNum);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setActionsAndStatesNumber(unsigned int A, unsigned int S) {
  actionsNum = A;
  statesNum = S;
  max_w.assign(actionsNum, 0);
  min_w.assign(actionsNum, 0);

	weights.clear();
	vector<double> tmp_w;
  tmp_w.assign(statesNum, 0);
	for(unsigned int idy = 0; idy < actionsNum; idy++) {
		weights.push_back(tmp_w);
	}

  world = new World();
  world->setActionsAndStatesNumber(actionsNum, statesNum);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setGoalState(unsigned int value) {
  world->setGoalState(value);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setGoalState(unsigned int x, unsigned int y) {
  world->setGoalState(x, y);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setLearningParameter_exploitation(double value) {
  beta = value;     // Reliability for action
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setLearningParameter_discountFactor(double value) {
  gamma = value;    // Discount factor
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setLearningParameter_learningRate(double value) {
  epsilon = value;  // Learning rate
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setLearningParameters(vector<double> values) {
  epsilon = values[0];  // Learning rate
  gamma = values[1];    // Discount factor
  beta = values[2];     // Reliability for action
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<vector<double> > Sarsa::getWeightsValues(void) {
  return(weights);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setStateActivationMode(char value) {
  world->setStateActivationMode(value);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setStateActivationMode(char value, unsigned int size) {
  world->setStateActivationMode(value, size);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setActionSelectionMode(char value) {
  actionSelectionMode = value;
  world->setActionSelectionMode(value);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setOperationMode(char value) {
  world->setOperationMode(value);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::sarsaAlgorithm(unsigned int trials) {
  static time_t startTime;
  static time_t endTime;
  unsigned int stepsOfCurrentTrial = 0;
  bool success = false;
  double reward = 0;
  vector<double> states;
  vector<double> statesPrime;
  unsigned int action = 0;
  unsigned int actionPrime = 0;
  double Qsa = 0.0;
  double QsaPrime = 0.0;

  int topTraining = 0;
  double delta = 0;
  vector<double> out_strength;
  for(unsigned int i = 0; i < trials; i++) {
    if(verbosity >= VERBOSITY_LOW) {
      time(&endTime);
      double dif = 0;
      int minutes = 0;  int seconds = 0;
      dif = difftime(endTime, startTime);
      startTime = endTime;
      minutes = dif / 60; seconds = ((int)dif) % 60;
      fprintf(stdout, "\n*** SARSA - STARTING A NEW TRIAL (%4d/%4d) ***",
            i,trials);
      fprintf(stdout, " -> %2d:%2d\n", minutes, seconds);
    }

    // FIRST STEP
    success = false;
    reward = 0;
    stepsOfCurrentTrial = 0;
    // (i1) real old state - Select random position
    if(verbosity >= VERBOSITY_MEDIUM)
      fprintf(stdout, "(%2d) SARSA -> (i1) Updating states\n", i);
    states = world->getInitialStates(); // *** CONTACT WITH THE WORLD

    // (8) Check for reward
    reward = world->getRewardValue();// *** CONTACT WITH THE WORLD
    if(reward == 1) success = true;
    if(verbosity >= VERBOSITY_MEDIUM)
      fprintf(stdout, "(%2d) SARSA -> Getting reward info -> %f\n",i,reward);

    // (i2) Compute the strength of the stimuli to certain input
    if(verbosity >= VERBOSITY_MEDIUM)
      fprintf(stdout, "(%2d) SARSA -> (i2) Computing output strength\n", i);
    out_strength = computeOutputStrength(states);
    // (i3) (Select action)
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "SARSA (%d) -> ",i);
    action = selectAction(out_strength);
    if(verbosity >= VERBOSITY_MEDIUM)
      fprintf(stdout, "(%2d) SARSA -> (i3) Selecting action -> %d\n",
            i, action);
    // (i4) Compute action-state values (value)
    Qsa = computeCurrentEstimate(action, states);
    if(verbosity >= VERBOSITY_MEDIUM)
      fprintf(stdout,
        "(%2d) SARSA -> (i4) Computing current estimated -> %f\n", i, Qsa);

    // REST OF STEPS - EXECUTED UNTIL SUCCESS
    while(!success) {
      // (0)-(1) Act and infer new state
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> Executing action -> %d\n", i, action);
      topTraining = world->actionExecution(action);// *** CONTACT WITH THE WORLD
      if(topTraining == _FINISH_LEARNING) {
        success = true;
      } else {
      // (1) Infer new state from the world (read new state)
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> Updating states\n", i);
      statesPrime = world->getCurrentStates();// *** CONTACT WITH THE WORLD
      // (8) Check for reward
      reward = world->getRewardValue();// *** CONTACT WITH THE WORLD
      if(reward == 1) success = true;
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> Getting reward info -> %f\n",i,reward);
      // (2) (action unit input) Compute the input signal to the outut neuron
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> Computing output strength\n", i);
      out_strength = computeOutputStrength(statesPrime);
      // (3) Select action
      if(verbosity >= VERBOSITY_LOW)
        fprintf(stdout, "SARSA (%d) -> ",i);
      actionPrime = selectAction(out_strength);
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> Selecting action -> %d\n",
              i,actionPrime);
      // (4) Compute action-state values (value)
      QsaPrime = computeCurrentEstimate(actionPrime, statesPrime);
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> "
          "Computing current estimated -> %f\n", i, QsaPrime);
      // (5) Prediction error
      delta = computePredictionError(QsaPrime, Qsa, reward);
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> "
          "Computing prediction error -> %f\n",i,delta);
      // (6) weights update
      if(verbosity >= VERBOSITY_MEDIUM)
        fprintf(stdout, "(%2d) SARSA -> Updating weights\n", i);
      updateWeights(action, states, delta);
      // (7) update action-state (new becomes old)
      states = statesPrime;
      Qsa = QsaPrime;
      action = actionPrime;
      // (9) Stats and verbosity
      stepsOfCurrentTrial++;
      }
    }
    if (weightsUpdate == _UPDATE_WEIGHTS) {
      exportWeightsToFile();
    }
    exportStatsToFile(i, trials, stepsOfCurrentTrial);
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<double> Sarsa::computeOutputStrength(vector<double> s_values) {
  vector<double> outputStrength(actionsNum, 0);

  // Implementation for conventional SARSA. All weights have value >= zero
//  for(unsigned int i = 0; i < actionsNum; i++) {
//    for(unsigned int j = 0; j < statesNum; j++) {
//      outputStrength[i] = outputStrength[i] + weights[i][j]*s_values[j];
//    }
//  }

  // Implementation when using Gaussian state activation.
  // As side effect weights values turn real values, also to compare weights
  // strengt we can for example compare their absolute values.
  // Weights Normalization
  double max = 0; double min = 1;
  double maxMagnitude = 0;
  unsigned int a_num = actionsNum;
  unsigned int s_num = statesNum;
  for(unsigned int idy = 0; idy < a_num; idy++) {
    for(unsigned int idx = 0; idx < s_num; idx++) {
      if(weights[idy][idx] >= max)  max = weights[idy][idx];
      if(weights[idy][idx] <= min)  min = weights[idy][idx];
      if(abs(weights[idy][idx]) >= maxMagnitude)
        maxMagnitude = abs(weights[idy][idx]);
    }
  }
  bool negativeValues = false;
  if(min < 0) {
    negativeValues = true;
//    min = -min;
//    max = max + min;
  }

  for(unsigned int idy = 0; idy < a_num; idy++) {
    for(unsigned int idx = 0; idx < s_num; idx++) {
      double tmp_weight = abs(weights[idy][idx]);
//      if(tmp_weight < 0) {
//        tmp_weight = -tmp_weight;
//      } else if((tmp_weight > 0) && negativeValues) {
//        tmp_weight = tmp_weight + min;
//      }
      // Normalize
//      if(max != 0)
//        tmp_weight = tmp_weight/max;
      outputStrength[idy] += tmp_weight*s_values[idx];
    }
  }
  return(outputStrength);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int Sarsa::selectAction(vector<double> outputStrength) {
  unsigned int selectedAction = 0;
  unsigned int stronger = 0;
  double denominator = 0.0;
  double tmpProb = 0.0;
  vector<double> actionProbability(actionsNum, 0.0);
  double probability = RNG.randd();
  double accActionProb = 0.0;

  switch (actionSelectionMode) {
    case _SOFTMAX:
      // Search for the stronger action and sum all output strength
      for(unsigned int idy = 0; idy < actionsNum; idy++) {
        tmpProb = exp(beta*outputStrength[idy]);
        actionProbability[idy] = (tmpProb);
        denominator += tmpProb;
        if(actionProbability[idy] >= actionProbability[stronger]) {stronger = idy;}
        if(verbosity >= VERBOSITY_MEDIUM) {
          fprintf(stdout, "SARSA -> ACTION STRENGTH %.10f / PROB: %f\n",
            outputStrength[idy], tmpProb);
        }
      }

      // Sort of winner take all implementation
      for (unsigned int idy = 0; idy < actionsNum; idy++) {
        actionProbability[idy] = actionProbability[idy]/denominator;
        accActionProb += actionProbability[idy];
        if (probability <= accActionProb) {
          selectedAction = idy;
          break;
        }
      }
      break;

    default:
      selectedAction = world->getNextAction();
      break;
  }

  if(verbosity >= VERBOSITY_LOW) {
    fprintf(stdout, "SARSA SELECTED ACTION: %2d - STRONGER ACTION: "
      "%2d", selectedAction, stronger);
    if (selectedAction == stronger)
    	fprintf(stdout, " *****");
    fprintf(stdout, "\n");
  }
  return(selectedAction);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double Sarsa::computeCurrentEstimate(unsigned int Ai, vector<double> s_values) {
  double Qsa = 0;
  unsigned int s_max = s_values.size(); // Number of states
  // Use this loop if your are using a fuzzy distribution of states
  for(unsigned int j = 0; j < s_max; j++) {
    // Use this line if the actions activation and states are fuzzy values
    Qsa = Qsa + (weights[Ai][j] * s_values[j]);
  }

  return(Qsa);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double Sarsa::computePredictionError(double QPrime, double Q, double reward) {
  double delta = 0;
  delta = (1 - reward) * (gamma*QPrime);
  delta += reward - Q;
  return(delta);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::updateWeights(unsigned int Ai, vector<double> s_values, double delta) {
  unsigned int s_max = s_values.size(); // Number of states
  if (weightsUpdate == _UPDATE_WEIGHTS) {
    for(unsigned int j = 0; j < s_max; j++) {
      weights[Ai][j] = weights[Ai][j] + epsilon*delta*s_values[j];
    }
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::enableWeightUpdate(void) {
  weightsUpdate = _UPDATE_WEIGHTS;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::disableWeightUpdate(void) {
  weightsUpdate = _KEEP_WEIGHTS_FROM_PREVIOUS_ITERATION;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setVerbosity(unsigned int value) {
  verbosity = value;
  world->setVerbosity(verbosity);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::setWeightsSourceTo(char value) {
  weightsSource = value;
  vector<double> tmp_w;

  switch (weightsSource) {
  	case _SET_WEIGHTS_TO_ZERO:
      weights.clear();
      tmp_w.assign(statesNum, 0);
      for(unsigned int idr = 0; idr < actionsNum; idr++) {
        weights.push_back(tmp_w);
      }
      if(verbosity >= VERBOSITY_LOW) {
        fprintf(stdout, "*** SARSA - Weights were initialized with zero"
          " values:: a = %d  s = %d***\n", actionsNum, statesNum);
      }
  		break;

  	case _GENERATE_RANDOM_WEIGHTS:
      weights.clear();
      tmp_w.assign(statesNum, 0);
      for (unsigned int idr = 0; idr < actionsNum; idr++) {
        for(unsigned int idc = 0; idc < statesNum; idc++) {
          tmp_w[idc] = RNG.randd();
        }
        weights.push_back(tmp_w);
      }
      if(verbosity >= VERBOSITY_LOW) {
        fprintf(stdout, "*** SARSA - Weights were randomly initialized"
          " values:: a = %d  s = %d***\n", actionsNum, statesNum);
      }
  		break;

  	case _KEEP_WEIGHTS_FROM_PREVIOUS_ITERATION:
      if(verbosity >= VERBOSITY_LOW) {
        fprintf(stdout, "*** SARSA - Weights have not been changed"
          " values:: a = %d  s = %d***\n", actionsNum, statesNum);
      }
  		break;

  	case _WEIGHTS_FROM_FILE:
      loadWeightsFromFile();
  		break;

  	default:
  		break;
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::printProgramVersion(void) {
  fprintf(stdout, "***********************************************************"
    "*********************\n");
  fprintf(stdout, "SARSA - Reinforcement Learning Algorithm\n");
  fprintf(stdout, "Program version: 0.2\n");
  fprintf(stdout, "Author: Nicolas Navarro\n");
  fprintf(stdout, "Contact: nicolas.navarro.guerrero@gmail.com\n");
  fprintf(stdout, "Created: November 2010\n");
  fprintf(stdout, "Last Modification: April 2012\n");
  fprintf(stdout, "***********************************************************"
    "*********************\n");
}
//-----------------------------------------------------------------------------
// TODO: Check how to import numbers in scientific notation or float point
// notation to keep accuracy
//-----------------------------------------------------------------------------
bool Sarsa::loadWeightsFromFile() {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_weights_file_name);

  bool retvalue = false;
  if(verbosity >= VERBOSITY_LOW)
    fprintf(stdout, "\n*** SARSA - Searching for Weights file:"
      " \"%s\" ***\n", fileName.c_str());

	ifstream infile;
	infile.open(fileName.c_str());

  if(infile.is_open()) {
    string s;
    double weightValue;
    vector<double> w_tmp;

    weights.clear();
    while(getline(infile, s)) {
      string::iterator it;
      w_tmp.clear();
      istringstream ss(s);  // extract doubles from string (space separated)
      while( ss >> weightValue ) {
        w_tmp.push_back(weightValue);
      }
      weights.push_back(w_tmp);
    }

    infile.close();

    actionsNum = weights.size();
    statesNum = weights[0].size();
    max_w.assign(actionsNum, 0);
    min_w.assign(actionsNum, 0);
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "SARSA -> %d output units (actions) and %d input units"
        " (state) were detected and loaded\n", actionsNum, statesNum);
    retvalue = true;
  } else {
    retvalue = false;
    weightsSource = _KEEP_WEIGHTS_FROM_PREVIOUS_ITERATION;
    if(verbosity >= VERBOSITY_LOW) {
      fprintf(stdout,"SARSA -> Weights File Not found (%s)\n",fileName.c_str());
      fprintf(stdout,"SARSA -> Weights from previous iteration will be used instead\n");
    }
  }
  return(retvalue);
}
//-----------------------------------------------------------------------------
// TODO: Check how to export numbers in scientific notation or float point
// notation to keep accuracy
//-----------------------------------------------------------------------------
void Sarsa::exportWeightsToFile(void) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_weights_file_name);

  if(verbosity >= VERBOSITY_LOW)
    fprintf(stdout, "SARSA -> EXPORTING WEIGHTS TO FILE: %s", fileName.c_str());

  FILE *fp;
  if( (fp = fopen(fileName.c_str(), "w")) ) {
    for(unsigned int i = 0; i < actionsNum; i++) {
      double max = 0;
      double min = 1;
      for(unsigned int j = 0; j < statesNum; j++) {
        fprintf(fp, "%.20f ", weights[i][j]);
        if(weights[i][j] >= max)  max = weights[i][j];
        if(weights[i][j] <= min)  min = weights[i][j];
      }
      max_w[i] = max; min_w[i] = min;
      fprintf(fp, "\n");
    }
    fclose(fp);
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "   DONE");
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "An error occurs when opening %s", fileName.c_str());
  }
  if(verbosity >= VERBOSITY_LOW)
    fprintf(stdout, "\n");
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::exportStatsToFile(unsigned int _currentTrial, unsigned int _expectedTrials, unsigned int _actions) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_stats_file_name);

  if(verbosity >= VERBOSITY_LOW)
    fprintf(stdout, "SARSA -> EXPORTING WEIGHTS SUMMARY TO FILE: %s",
          fileName.c_str());

  FILE *fp;
  double percentageLearnedWeights = 0;
  unsigned int numberVisitedStates = 0;
  vector<double> tmp_states(statesNum, 0.0);
  vector<double> percentageWeightsPerAction(actionsNum, 0.0);
  vector<unsigned int> learnedWeightsPerAction(actionsNum, 0);
  vector<unsigned int> trialInformation(4, 0);
  trialInformation[0] = _currentTrial;
  trialInformation[1] = _expectedTrials;
  trialInformation[2] = _actions;

  if( (fp = fopen(fileName.c_str(), "a")) ) {
    fprintf(fp, "****************************************"
            "***************************************\n");
    fprintf(fp, "Learning step %d / %d\n", _currentTrial, _expectedTrials);

    for(unsigned int i = 0; i < actionsNum; i++) {
      learnedWeightsPerAction[i] = 0;
      double max = 0;
      double min = 1;
      for(unsigned int j = 0; j < statesNum; j++) {
        tmp_states[j] += abs(weights[i][j]);
        if(weights[i][j] != 0)  learnedWeightsPerAction[i]++;
        if(weights[i][j] >= max)  max = weights[i][j];
        if(weights[i][j] <= min)  min = weights[i][j];
      }
      percentageWeightsPerAction[i] = (learnedWeightsPerAction[i]*1.0)/(statesNum*1.0);
      percentageLearnedWeights += percentageWeightsPerAction[i];
      fprintf(fp, "Action %d: Learned weights %3d ( %.2f\% )/ %3d -- Max: %f "
            "-- Min: %f\n", i,learnedWeightsPerAction[i],percentageWeightsPerAction[i],statesNum,max,min);
      max_w[i] = max; min_w[i] = min;
    }
    for (unsigned int idr = 0; idr < statesNum; idr++) {
      if(tmp_states[idr] != 0) numberVisitedStates++;
    }
    trialInformation[3] = numberVisitedStates;
    fprintf(fp, "_______________________________ %.3f\% \n",percentageLearnedWeights/4);
    fprintf(fp, "Number of steps required in this trial %d \n",_actions);
    fprintf(fp, "Total number of visited states up to this trial %5d \n",numberVisitedStates);
    fclose(fp);

    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "   DONE\n");

    exportCompactStatsFormatToFile(trialInformation, learnedWeightsPerAction);
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "An error occurs when opening %s\n", fileName.c_str());
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::exportCompactStatsFormatToFile(vector<unsigned int> trialInfo, vector<unsigned int> actionInfo) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_compact_stats_file_name);

  if(verbosity >= VERBOSITY_LOW)
    fprintf(stdout, "SARSA -> EXPORTING LEARNING STATS IN COMPACT FORMAT TO FILE: %s",
          fileName.c_str());

  FILE *fp;

  if( (fp = fopen(fileName.c_str(), "a")) ) {
    fprintf(fp, "%3d \t %3d \t %5d ", trialInfo[0],trialInfo[1],trialInfo[2]);
    fprintf(fp, "\t");
    fprintf(fp, "%4d \t %4d \t %1.6f \t ", statesNum,trialInfo[3],((trialInfo[3]*1.0)/(statesNum*1.0)));
    for (unsigned int idr = 0; idr < actionsNum; idr++) {
      fprintf(fp, "\t | \t ");
      fprintf(fp, "%d \t %d \t %1.6f", idr, actionInfo[idr], (actionInfo[idr]*1.0)/(statesNum*1.0));
    }
    fprintf(fp, "\n");
    fclose(fp);

    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "   DONE\n");
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "An error occurs when opening %s\n", fileName.c_str());
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::exportWeightsToImages(void) {
  world->exportWeightsToImages(weights);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void Sarsa::exportWeightsToImages(string prefix) {
  world->exportWeightsToImages(weights, prefix);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double Sarsa::getPercentageVisitedStates(void) {
  unsigned int numberVisitedStates = 0;
  vector<double> tmp_states(statesNum,0.0);

  for(unsigned int i = 0; i < actionsNum; i++) {
    for(unsigned int j = 0; j < statesNum; j++) {
      tmp_states[j] += abs(weights[i][j]);
    }
  }

  for (unsigned int idr = 0; idr < statesNum; idr++) {
    if(tmp_states[idr] != 0) numberVisitedStates++;
  }
  double retvalue = (numberVisitedStates*1.0)/(statesNum*1.0);
  return(retvalue);
}
//*****************************************************************************
// SARSA Class Implementation: END
//*****************************************************************************
