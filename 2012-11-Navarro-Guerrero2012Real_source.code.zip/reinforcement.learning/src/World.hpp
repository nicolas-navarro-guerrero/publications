//*****************************************************************************
// Title: World.hpp
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: February 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

#ifndef __WORLD_LIBRARY_H__
#define __WORLD_LIBRARY_H__

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
//-----------------------------------------------------------------------------
// Specific tool libraries

//-----------------------------------------------------------------------------
// Own Libraries
#include "Verbosity.hpp"
#include "Bitmap.hpp"
#include "Normal.hpp"
#include "RandomNumberGenerators.hpp"

//*****************************************************************************
// Global Variables Definition
using namespace std;

enum _STATE_SPACE_VARIABLES_ {
  _VARIABLE_X_AXIS = 0,
  _VARIABLE_Y_AXIS = 1,
  _VARIABLE_DISTANCE
};

enum _STATE_SPACE_EXPLORATION_MODE_ {
  _RANDOM_EXPLORATION = 0,
  _TELE_OPERATED,
  _DEFAULT_HARD_CODED_BEHAVIOR,
  _BATCH
};

enum _STATE_ACTIVATION_MODE_ {
  _SINGLE_STATE_ACTIVATION = 0,
  _GAUSSIAN_STATE_ACTIVATION,
  _NEIGHBORHOOD_STATE_ACTIVATION
};

enum _ACTION_SELECTION_MODE_ {
  _SOFTMAX = 0,
  _HARD_CODED_POLICY,
  _ACTIONS_FROM_FILE,
  _USER_GENERATED
};

enum _ACTION_CODE_NUMBER {
  _MOVE_FORWARDS = 0,
  _MOVE_BACKWARDS,
  _MOVE_LEFT,
  _MOVE_RIGHT,
  _TURN_LEFT,
  _TURN_RIGHT,
  _FREEZE,
  _STOCHASTIC_ACTION_SELECTION,
  _RESTART_TRIAL,
  _FINISH_LEARNING
};
enum CurrentStateCodes {
  LANDMARK_OUT_OF_IMAGE = 0,
  LANDMARK_NOT_DETECTED,
  LANDMARK_DETECTED,
  FALL,
  CRASH,
};

const bool FORWARDS = true;
const bool BACKWARDS = false;
const double sigma = 0.85;

const string default_raw_data_file_name = "raw_action-state-sequences.txt";
const string default_raw_examples_file_name = "raw_examples-action-state-sequences.txt";
const string default_output_folder = "../log/";
//*****************************************************************************
/**
 * World Class Declaration
 */
//*****************************************************************************
class World {
  public:
    World();
    ~World();
  /**
   * getInitialStates(void);
   * Compute abstract states from robot physical status
   */
    vector<double> getInitialStates(void);
    double getRewardValue(void);
    int actionExecution(unsigned int value);
    vector<double> getCurrentStates(void);

    void setGoalState(unsigned int value);
    void setGoalState(unsigned int x, unsigned int y);
    void setGoalStateAlternatives(vector<double> value);
    void setGoalSubstateCoordinates(vector<double> value);
    unsigned int getNextAction(void);
    unsigned int getNextAction(char value);

  /**
   * setStateActivationMode(unsigned int value, unsigned int size);
   * This function allows to select classical SARSA with single state activation
   * or switch to Gaussian activation full or limited to a neighborhood of size
   * "size". Single and Gaussian descart the value of size.
   */
    void setStateActivationMode(char value);
    void setStateActivationMode(char value, unsigned int size);
    // Only considered if operation mode is different of BATCH
    void setActionSelectionMode(char value);
    void setOperationMode(char value);
    bool trainingExamplesAvailable(void);

  /**
   * setActionsAndStatesNumber(unsigned int A, unsigned int S);
   * Set the maximum action and state number, it creates a square scenario and
   * by default the rewarding state is set in the middle os the sqare.
   */
    void setActionsAndStatesNumber(unsigned int A, unsigned int S);
    void setVerbosity(unsigned int value);

    void exportWeightsToImages(vector<vector<double> > weights);
    void exportWeightsToImages(vector<vector<double> > weights, string prefix);
    void exportWeightsToImages_3substates(vector<vector<double> > weights, string prefix);

  protected:

  private:
    void init(void);
    normal_distribution bump;
    BitmapLite logPict;
    RandomNumberGenerators RNG;

    unsigned int determineSubstateValueOfVariable(unsigned int value);
    unsigned int determineCurrentStateValue(void);
    vector<double> fuzzificationOfStateSpace(vector<int> values, vector<int> maxSizes);
    vector<double> fuzzificationOfNeighborhood(vector<int> values, vector<int> maxSizes, int neighborhoodSize);
    vector<double> fuzzificationOfNeighborhood(vector<int> values, vector<int> maxSizes, vector<int> neighborhoodSize);

    void exportRawSensoryValuesToFile(vector<double> value);
    void exportRawSensoryValuesToFile(double value);
    void exportRewardValueToFile(double value);
    void exportExecutedActionToFile(unsigned int value);
    bool load_RawSensorReadings_Reward_And_Actions(void);

    unsigned int getNextActionFromUser(void);
    unsigned int getNextLoadedActionFromFile(void);
    unsigned int getNextActionFromDefaultPolicy(void);
    void act(char value);

    unsigned int actionsNum;
    unsigned int statesNum;
    vector<double> states;
    int currentState;
    int goalState;
    vector<int> alternativeGoalStates;
    double currentRewardValue;
    vector<double> substateSensorValues;
    vector<int> substateValues; // It has be able to handle negative values
    vector<int> substateSizes;
    unsigned int substateNumber;
    vector<vector<int> > goalSubstateCoordinates;

    char operationMode;
    char userSelectedAction;
    char actionSelectionMode;
    char stateActivationMode;
    int stateNeighborhoodSize;
    vector<int> stateNeighborhoodSizes;

    unsigned int verbosity;
    bool loadedExamples;
    unsigned int _IDX_REWARD_EXAMPLE;
    unsigned int _IDX_ACTION_EXAMPLE;
    unsigned int currentTrainingStep;
    unsigned int maxTrainingSteps;
    unsigned int examples_num;
    vector<vector<double> > examples;
};
//*****************************************************************************
// World Class Declaration: END
//*****************************************************************************

#endif  // __WORLD_LIBRARY_H__
