//*****************************************************************************
// Title: World.cpp
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: February 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

//*****************************************************************************
// Libraries Declaration
#include "World.hpp"

//*****************************************************************************
// Global Variables Definition


//*****************************************************************************
// World Class Implementation: BEGIN
//*****************************************************************************
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
World::World() {
  init();
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
World::~World() {
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::init(void) {
  operationMode = _RANDOM_EXPLORATION;
  stateActivationMode = _SINGLE_STATE_ACTIVATION;
  stateNeighborhoodSize = 0;
  userSelectedAction = 0;

  currentState = 0;
  substateNumber = 2;
  substateValues.assign(substateNumber,0);
  substateSizes.assign(substateNumber,0);
  substateSensorValues.assign(substateNumber,0);

  verbosity = VERBOSITY_LOW;
  currentTrainingStep = 0;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<double> World::getInitialStates(void) {
  currentState = 0;
  states.clear();
  states.assign(statesNum, 0);
  substateValues.clear();
  substateValues.assign(substateNumber, 0);
  substateSensorValues.clear();
  substateSensorValues.assign(substateNumber,0);

  if (operationMode == _BATCH) {
    if(!trainingExamplesAvailable()) {
      fprintf(stdout, "WORLD -> Sorry. No training examples are yet available."
              " We will continue with the standard procedure.\n");
      // Sens environment and determine current state
      for (unsigned int idx = 0; idx < substateNumber; idx++) {
        // Generate random starting position
        // Generate random starting position away from goal state
////        do {
//          substateValues[idx] = RNG.randi(substateSizes[idx]-1);
////        } while( abs(substateValues[idx]*1.0-goalSubstateCoordinates[0][idx]*1.0) < ((goalSubstateCoordinates[0][idx]*2)/3) );
        substateValues[idx] = determineSubstateValueOfVariable(idx);
      }
    } else {
      // IF TRAINING EXAMPLES ARE AVAILABLE RETURN STORED VALUE
      for (unsigned int idx = 0; idx < substateNumber; idx++) {
      	substateValues[idx] = examples[currentTrainingStep][idx];
      }
    }
  } else {
    // Sens environment and determine current state
    for (unsigned int idx = 0; idx < substateNumber; idx++) {
      // Generate random starting position
      // Generate random starting position away from goal state
//      do {
        substateValues[idx] = RNG.randi(substateSizes[idx]-1);
//      } while( abs(substateValues[idx]*1.0-goalSubstateCoordinates[0][idx]*1.0) < ((goalSubstateCoordinates[0][idx]*2)/3) );
//      if (idx == 0) {
////        if (RNG.randd() < 0.5) {
////          substateValues[idx] = 0;
////        } else {
////          substateValues[idx] = substateSizes[idx]-1;
////        }
//          substateValues[idx] = (substateSizes[idx]-1)/2;
//      } else {
//        substateValues[idx] = 0;
//      }
      substateValues[idx] = determineSubstateValueOfVariable(idx);
    }
  }

  currentState = determineCurrentStateValue();
  switch(stateActivationMode) {
    case _SINGLE_STATE_ACTIVATION:
      states[currentState] = 1;
      break;

    case _NEIGHBORHOOD_STATE_ACTIVATION:
      states = fuzzificationOfNeighborhood(substateValues,substateSizes,stateNeighborhoodSize);
      break;

    case _GAUSSIAN_STATE_ACTIVATION:
      states = fuzzificationOfStateSpace(substateValues,substateSizes);
      break;

    default:
      states[currentState] = 1;
      break;
  }

  if(verbosity >= VERBOSITY_LOW) {
    fprintf(stdout, "WORLD -> Agent's current position is state: %4d\n", currentState);
    fprintf(stdout, "WORLD -> The agent goal is state:           %4d\n", goalState);
    fprintf(stdout, "WORLD -> The current state is given by the following variable value:\n");
    for (unsigned int idx = 0; idx < substateNumber; idx++) {
      fprintf(stdout, "            variable %2d with state value %2d / %2d"
        " -> goal is at: %2d\n",idx,substateValues[idx],substateSizes[idx],goalSubstateCoordinates[0][idx]);
    }
    fprintf(stdout, "----------------------------------------------------------------------\n");
  }
  return(states);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
vector<double> World::getCurrentStates(void) {
  currentState = 0;
  states.clear();
  states.assign(statesNum, 0);

  if (operationMode == _BATCH) {
    if(!trainingExamplesAvailable()) {
      fprintf(stdout, "WORLD -> Sorry. No training examples are yet available."
              " We will continue with the standard procedure.\n");
      // Sens environment and determine current state
      for (unsigned int idx = 0; idx < substateNumber; idx++) {
        substateValues[idx] = determineSubstateValueOfVariable(idx);
      }
    } else {
      // IF TRAINING EXAMPLES ARE AVAILABLE RETURN STORED VALUE
      for (unsigned int idx = 0; idx < substateNumber; idx++) {
      	substateValues[idx] = examples[currentTrainingStep][idx];
      }
    }
  } else {
    // Sens environment and determine current state
    for (unsigned int idx = 0; idx < substateNumber; idx++) {
      substateValues[idx] = determineSubstateValueOfVariable(idx);
    }
  }

  currentState = determineCurrentStateValue();
  switch(stateActivationMode) {
    case _SINGLE_STATE_ACTIVATION:
      states[currentState] = 1;
      break;

    case _NEIGHBORHOOD_STATE_ACTIVATION:
      states = fuzzificationOfNeighborhood(substateValues,substateSizes,stateNeighborhoodSize);
      break;

    case _GAUSSIAN_STATE_ACTIVATION:
      states = fuzzificationOfStateSpace(substateValues,substateSizes);
      break;

    default:
      states[currentState] = 1;
      break;
  }

  if(verbosity >= VERBOSITY_LOW) {
    fprintf(stdout, "WORLD -> Agent's current position is state: %4d\n", currentState);
    fprintf(stdout, "WORLD -> The agent goal is state:           %4d\n", goalState);
    fprintf(stdout, "WORLD -> The current state is given by the following variable value:\n");
    for (unsigned int idx = 0; idx < substateNumber; idx++) {
      fprintf(stdout, "            variable %2d with state value %2d / %2d"
        " -> goal is at: %2d\n",idx,substateValues[idx],substateSizes[idx],goalSubstateCoordinates[0][idx]);
    }
    fprintf(stdout, "----------------------------------------------------------------------\n");
  }
  return(states);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double World::getRewardValue(void) {
  double retvalue = 0.0;

  if (operationMode == _BATCH) {
    if(trainingExamplesAvailable()) {
      // IF TRAINING EXAMPLES ARE AVAILABLE RETURN STORED VALUE
      retvalue = examples[currentTrainingStep][_IDX_REWARD_EXAMPLE];
      if(currentState == goalState) currentTrainingStep++;
      if(currentTrainingStep >= maxTrainingSteps) currentTrainingStep = 0;
    } else {
      fprintf(stdout, "WORLD -> Sorry. No training examples are yet available."
              " We will continue with the standard procedure.\n");
    }
  } else {
    // Here insert the reward function
    if (currentState == goalState) {
      retvalue = 1;
    } else {
      retvalue = 0;
    }
    exportRewardValueToFile(retvalue);
  }

  if(verbosity >= VERBOSITY_MEDIUM) {
    fprintf(stdout, "WORLD -> REWARD value given at this state is: %1.6f *******\n", retvalue);
  } else if(retvalue != 0) {
    fprintf(stdout, "WORLD -> REWARD value given at this state is: %1.6f *******\n", retvalue);
  }

  currentRewardValue = retvalue;
  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setGoalState(unsigned int value) {
  goalState = value;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setGoalState(unsigned int x, unsigned int y) {
  goalState = x + y*substateSizes[0];

  goalSubstateCoordinates.clear();
  vector<int> tmp(2, 0);
  goalSubstateCoordinates.push_back(tmp);
  goalSubstateCoordinates[0][0] = x;
  goalSubstateCoordinates[0][1] = y;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setActionsAndStatesNumber(unsigned int A, unsigned int S) {
  actionsNum = A;
  statesNum = S;

  substateSizes[0] = lrint(sqrt(statesNum));    // maxColumns
  substateSizes[1] = statesNum/substateSizes[0];// maxRows

  // By default the rewarding state is in the middle of a square
  setGoalState(substateSizes[0]/2,substateSizes[1]/2);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setVerbosity(unsigned int value) {
  verbosity = value;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setOperationMode(char value) {
  operationMode = value;
  if (operationMode == _BATCH) {
    load_RawSensorReadings_Reward_And_Actions();
    if (!trainingExamplesAvailable()) {
      fprintf(stdout, "WORLD -> Sorry. No training examples are yet available.\n"
        " Training examples has to be saved under the following name:\n"
        "      %s%s"
        " We will continue with the standard procedure (Random Exploration).\n",
        default_output_folder.c_str(), default_raw_examples_file_name.c_str());
    }
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setStateActivationMode(char value) {
  stateActivationMode = value;
  stateNeighborhoodSize = 0;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::setStateActivationMode(char value, unsigned int size) {
  stateActivationMode = value;
  stateNeighborhoodSize = size;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
int World::actionExecution(unsigned int value) {
  int retvalue = value;

  if (operationMode == _BATCH) {
    // IF TRAINING EXAMPLES ARE AVAILABLE RETURN STORED VALUE
    retvalue = examples[currentTrainingStep][_IDX_ACTION_EXAMPLE];
    currentTrainingStep++;
  } else {
    if (userSelectedAction == _FINISH_LEARNING) {
      retvalue = _FINISH_LEARNING;
    } else if (userSelectedAction == _RESTART_TRIAL) {
      retvalue = _FINISH_LEARNING;
    } else{
      // Here insert the agent-environment dynamic or motor commands
      act(value);
      exportExecutedActionToFile(value);
    }
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int World::getNextAction(void) {
  unsigned int retvalue;

  switch (actionSelectionMode) {
    case _HARD_CODED_POLICY:
      retvalue = getNextActionFromDefaultPolicy();
      break;

    case _ACTIONS_FROM_FILE:
      retvalue = getNextLoadedActionFromFile();
      break;

    case _USER_GENERATED:
      retvalue = getNextActionFromUser();
      break;

    default:
      retvalue = getNextActionFromDefaultPolicy();
      break;
  }
  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int World::getNextLoadedActionFromFile(void) {
  unsigned int retvalue;
  retvalue = lrint(examples[currentTrainingStep][_IDX_ACTION_EXAMPLE]);
  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int World::getNextActionFromDefaultPolicy(void) {
  unsigned int retvalue = 0;

  if (RNG.randd() < 0.5) {
    // Select a sideward movement
    if (substateValues[1] < goalSubstateCoordinates[0][1]) {
      retvalue = _MOVE_FORWARDS;
    } else if (substateValues[1] > goalSubstateCoordinates[0][1]) {
      retvalue = _MOVE_BACKWARDS;
    } else if (substateValues[1] == goalSubstateCoordinates[0][1]) {
      // Select a forward or backward movement
      if (substateValues[0] < goalSubstateCoordinates[0][0]) {
        retvalue = _MOVE_RIGHT;
      } else if (substateValues[0] > goalSubstateCoordinates[0][0]) {
        retvalue = _MOVE_LEFT;
      }
    }
  } else {
    // Select a forward or backward movement
    if (substateValues[0] < goalSubstateCoordinates[0][0]) {
      retvalue = _MOVE_RIGHT;
    } else if (substateValues[0] > goalSubstateCoordinates[0][0]) {
      retvalue = _MOVE_LEFT;
    } else if (substateValues[0] == goalSubstateCoordinates[0][0]) {
      // Select a sideward movement
      if (substateValues[1] < goalSubstateCoordinates[0][1]) {
        retvalue = _MOVE_FORWARDS;
      } else if (substateValues[1] > goalSubstateCoordinates[0][1]) {
        retvalue = _MOVE_BACKWARDS;
      }
    }
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
// Here insert the agent-environment dynamic or motor commands
//-----------------------------------------------------------------------------
void World::act(char value) {
  switch(value) {
    case _MOVE_FORWARDS:
      substateValues[1]++;  // row++;
      if(substateValues[1] >= substateSizes[1])
        substateValues[1] = substateSizes[1]-1;
      break;

    case _TURN_RIGHT:
      break;

    case _MOVE_BACKWARDS:
      substateValues[1]--;  // row--;
      if(substateValues[1] <= 0) substateValues[1] = 0;
      break;

    case _TURN_LEFT:
      break;

    case _MOVE_LEFT:
      substateValues[0]--;  // column--;
      if(substateValues[0] <= 0) substateValues[0] = 0;
      break;

    case _MOVE_RIGHT:
      substateValues[0]++;  // column++;
      if(substateValues[0] >= substateSizes[0])
        substateValues[0] = substateSizes[0]-1;
      break;

    default:
      break;
  }
}
//-----------------------------------------------------------------------------
// Only considered if operation mode is different of BATCH
//-----------------------------------------------------------------------------
void World::setActionSelectionMode(char value) {
  actionSelectionMode = value;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
bool World::trainingExamplesAvailable(void) {
  return(loadedExamples);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportRawSensoryValuesToFile(double value) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_raw_data_file_name);

  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "WORLD -> EXPORTING RAW SENSORY VALUES TO FILE: %s",
      fileName.c_str());

  FILE *fp;
  if( (fp = fopen(fileName.c_str(), "a")) ) {
    fprintf(fp, "%2.20f \t", value);  // Saving sensor reading value
    fclose(fp);
    if(verbosity >= VERBOSITY_HIGH)
      fprintf(stdout, "   DONE");
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "\n   An error occurs when opening %s", fileName.c_str());
  }
  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "\n");
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportRawSensoryValuesToFile(vector<double> value) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_raw_data_file_name);

  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "WORLD -> EXPORTING RAW SENSORY VALUES TO FILE: %s",
      fileName.c_str());

  unsigned int sensorsNumbers = value.size();

  FILE *fp;
  if( (fp = fopen(fileName.c_str(), "a")) ) {
    for(unsigned int idx = 0; idx < sensorsNumbers; idx++) {
      fprintf(fp, "%2.20f \t", value[idx]);  // Saving sensor reading value
    }
    fclose(fp);
    if(verbosity >= VERBOSITY_HIGH)
      fprintf(stdout, "   DONE");
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "\n   An error occurs when opening %s", fileName.c_str());
  }
  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "\n");
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportRewardValueToFile(double value) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_raw_data_file_name);

  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "WORLD -> EXPORTING REWARD VALUE TO FILE: %s",
      fileName.c_str());

  FILE *fp;
  if( (fp = fopen(fileName.c_str(), "a")) ) {
    fprintf(fp, "%.20f \t", value);   // Saving reward value
    fclose(fp);
    if(verbosity >= VERBOSITY_HIGH)
      fprintf(stdout, "   DONE");
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "\n   An error occurs when opening %s", fileName.c_str());
  }
  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "\n");
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportExecutedActionToFile(unsigned int value) {
  string fileName;
  fileName.append(default_output_folder);
  fileName.append(default_raw_data_file_name);

  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "WORLD -> EXPORTING EXECUTED ACTION VALUE TO FILE: %s",
      fileName.c_str());

  FILE *fp;
  if( (fp = fopen(fileName.c_str(), "a")) ) {
    fprintf(fp, "%d \n", value);   // Saving executed action value
    fclose(fp);
    if(verbosity >= VERBOSITY_HIGH)
      fprintf(stdout, "   DONE");
  } else {
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "\n   An error occurs when opening %s", fileName.c_str());
  }
  if(verbosity >= VERBOSITY_HIGH)
    fprintf(stdout, "\n");
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
bool World::load_RawSensorReadings_Reward_And_Actions(void) {
  string fileName;
  fileName = default_output_folder;
  fileName.append(default_raw_examples_file_name);

  if(verbosity >= VERBOSITY_LOW)
    fprintf(stdout, "WORLD -> TRYING TO LOAD RAW TRAINING EXAMPLES: %s\n",
          fileName.c_str());

  loadedExamples = false; // Class Variable
	ifstream infile;
	infile.open(fileName.c_str());
  if(infile.is_open()) {
    string s;
    double values;
    vector<double> tmp;

    // Reading file
    examples.clear(); // Class Variable
    while(getline(infile, s)) {
      string::iterator it;
      tmp.clear();
      // extract doubles from string (space separated)
      istringstream ss(s);
      while( ss >> values ) {
        tmp.push_back(values);
      }
      // eliminate empty lines from input data
      if(tmp.size() != 0)
        examples.push_back(tmp);  // Class Variable
    }
    infile.close(); // Closing file

    // Processing read information
    examples_num = 0;       // Class Variable
    currentTrainingStep = 0;// Class Variable
    maxTrainingSteps = examples.size()-1; // Class Variable
    _IDX_ACTION_EXAMPLE = examples[0].size() - 1;
    _IDX_REWARD_EXAMPLE = _IDX_ACTION_EXAMPLE - 1;

    int example_avg_steps_number = 0;
    for(unsigned int idy = 0; idy < examples.size(); idy++) {
      example_avg_steps_number++;
      // CHANGE THIS ACCORDINGLY TO YOUR TRIAL TERMINATION CONDITION
      if((examples[idy][_IDX_REWARD_EXAMPLE] > 0) || (examples[idy][_IDX_ACTION_EXAMPLE] == -1))
        examples_num++;

      if(verbosity >= VERBOSITY_MAXIMUM) {
        for(unsigned int idx = 0; idx < examples[idy].size(); idx++) {
          if((idx != _IDX_ACTION_EXAMPLE) || (idx != _IDX_REWARD_EXAMPLE)) {
            fprintf(stdout, "S_%d = %f", idx, examples[idy][idx]);
          } else if(idx == _IDX_ACTION_EXAMPLE) {
            fprintf(stdout, "A = %f", examples[idy][idx]);
          } else if(idx == _IDX_REWARD_EXAMPLE) {
            fprintf(stdout, "R = %f", examples[idy][idx]);
          }
          fprintf(stdout, "\n");
        }
      }
    }
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "WORLD -> %d TRAINING EXAMPLES WERE LEADED: %f avg steps"
            " number. Total Steps Num: %d\n", examples_num,
            (1.0*example_avg_steps_number)/examples_num, maxTrainingSteps);
    loadedExamples = true;  // Class Variable
  } else {
    loadedExamples = false; // Class Variable
    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout,"            FILE NOT FOUND: (%s)\n",
        fileName.c_str());
  }

  return(loadedExamples);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportWeightsToImages_3substates(vector<vector<double> > weights, string prefix) {
  // Determine image width
  unsigned int width = 14;
  unsigned int height = 14;
  unsigned int deep = 10;

  // Extract information for a later weights Normalization
  double max = 0; double min = 1;
  unsigned int a_num = weights.size();
  unsigned int s_num = weights[0].size();
  for(unsigned int idy = 0; idy < a_num; idy++) {
    for(unsigned int idx = 0; idx < s_num; idx++) {
      if(weights[idy][idx] >= max)  max = weights[idy][idx];
      if(weights[idy][idx] <= min)  min = weights[idy][idx];
    }
  }

  vector<double> imgLine;       // pixels line
  vector<vector<double> > wholeImage;  // image

  // Generates a set of images per action
  for(unsigned int idt = 0; idt < a_num; idt++) {
    for(unsigned int idd = 0; idd < deep; idd++) {
      imgLine.clear();
      wholeImage.clear();
      // generate pixel information to the corresponding action and deep
      for (unsigned int idr = 0; idr < height; idr++) {
        imgLine.clear();
      	for (unsigned int idc = 0; idc < width; idc++) {
          int s = 0;
          s = idc + idr*width + idd*width*height;

          // weight normalization only if weights magnitude is greater than 1
          if ((weights[idt][s] < 0) && (abs(min) > 1)) {
            imgLine.push_back(weights[idt][s]/abs(min));
          } else if (weights[idt][s] > 0) {
            imgLine.push_back(weights[idt][s]/max);
          } else {
            imgLine.push_back(weights[idt][s]);
          }
      	}
      	wholeImage.push_back(imgLine);
      }
      // Generate image name
      std::stringstream imgName;
      imgName << default_output_folder.c_str();
      imgName << prefix.c_str();
      imgName << "_RF";
      switch (idt) {
      	case 0:
          imgName << "_forward";
      		break;

      	case 1:
          imgName << "_turn-right";
      		break;

      	case 2:
          imgName << "_backward";
      		break;

      	case 3:
          imgName << "_turn-left";
      		break;

      	case 4:
          imgName << "_move-left";
      		break;

      	case 5:
          imgName << "_move-right";
      		break;

      	default:
          imgName << "_";
      		break;
      }
      imgName << "_alpha";
      imgName << idd;
      imgName << ".pnm";

      if(verbosity >= VERBOSITY_LOW)
        fprintf(stdout, "WORLD -> EXPORTING WEIGHTS AS IMAGES: %s \n",
            imgName.str().c_str());

      // Export image to file
      logPict.saveRGBmapWeights(wholeImage, imgName.str().c_str());
    }
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportWeightsToImages(vector<vector<double> > weights, string prefix) {
  // Determine image width
  unsigned int width = substateSizes[0];  // maxColumns;

  vector<double> tmp_sizes;       // pixels line
  vector<vector<double> > array;  // image

  // Extract information for a later weights Normalization
  double max = 0; double min = 1;
  unsigned int a_num = weights.size();
  unsigned int s_num = weights[0].size();
  for(unsigned int idy = 0; idy < a_num; idy++) {
    for(unsigned int idx = 0; idx < s_num; idx++) {
      if(weights[idy][idx] >= max)  max = weights[idy][idx];
      if(weights[idy][idx] <= min)  min = weights[idy][idx];
    }
  }

  // Generates an image per action
  for(unsigned int idr = 0; idr < actionsNum; idr++) {
    // Set image size
    tmp_sizes.clear();
    array.clear();

    // generate pixel information to the corresponding action
    for(unsigned int idc = 0; idc < statesNum; idc++) {
      // Split states into lines of size "width"
      if((idc != 0) && ((idc%(width)) == 0)) {
        array.push_back(tmp_sizes);
        tmp_sizes.clear();
      }
      // weight normalization only if weights magnitude is greater than 1
//      tmp_sizes.push_back((weights[idr][idc]+min)/max);
      if ((weights[idr][idc] < 0) && (abs(min) > 1)) {
        tmp_sizes.push_back(weights[idr][idc]/abs(min));
      } else if ((weights[idr][idc] > 0) && (max > 1)) {
        tmp_sizes.push_back(weights[idr][idc]/max);
      } else {
        tmp_sizes.push_back(weights[idr][idc]);
      }
    }
    // last pixel line
    array.push_back(tmp_sizes);

    // Generate image name
    std::stringstream imgName;
    imgName << default_output_folder.c_str();
    imgName << prefix.c_str();
    imgName << "_visualize-weights";
    imgName << "_A";
    imgName << idr;
    imgName << ".pnm";

    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "WORLD -> EXPORTING WEIGHTS AS IMAGES: %s \n",
          imgName.str().c_str());

    // Export image to file
    logPict.saveRGBmapWeights(array, imgName.str().c_str());
  }
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void World::exportWeightsToImages(vector<vector<double> > weights) {
  // Determine image size
  unsigned int width = substateSizes[0];  // maxColumns;

  vector<double> tmp_sizes;       // pixels line
  vector<vector<double> > array;  // image

  // Extract information for a later weights Normalization
  double max = 0; double min = 1;
  unsigned int a_num = weights.size();
  unsigned int s_num = weights[0].size();
  for(unsigned int idy = 0; idy < a_num; idy++) {
    for(unsigned int idx = 0; idx < s_num; idx++) {
      if(weights[idy][idx] >= max)  max = weights[idy][idx];
      if(weights[idy][idx] <= min)  min = weights[idy][idx];
    }
  }

  // Generates an image per action
  for(unsigned int idr = 0; idr < actionsNum; idr++) {
    // Set image size
    tmp_sizes.clear();
    array.clear();

    // generate pixel information to the corresponding action
    for(unsigned int idc = 0; idc < statesNum; idc++) {
      // Split states into lines of size "width"
      if((idc != 0) && ((idc%(width)) == 0)) {
        array.push_back(tmp_sizes);
        tmp_sizes.clear();
      }
      // weight normalization only if weights magnitude is greater than 1
//      tmp_sizes.push_back((weights[idr][idc]+min)/max);
      if ((weights[idr][idc] < 0) && (abs(min) > 1)) {
        tmp_sizes.push_back(weights[idr][idc]/abs(min));
      } else if ((weights[idr][idc] > 0) && (max > 1)) {
        tmp_sizes.push_back(weights[idr][idc]/max);
      } else {
        tmp_sizes.push_back(weights[idr][idc]);
      }
    }
    // last pixel line
    array.push_back(tmp_sizes);

    // Generate image name
    std::stringstream imgName;
    imgName << default_output_folder.c_str();
    imgName << "visualize-weights";
    imgName << "_A";
    imgName << idr;
    imgName << ".pnm";

    if(verbosity >= VERBOSITY_LOW)
      fprintf(stdout, "WORLD -> EXPORTING WEIGHTS AS IMAGES: %s \n",
          imgName.str().c_str());

    // Export image to file
    logPict.saveRGBmapWeights(array, imgName.str().c_str());
  }
}
//-----------------------------------------------------------------------------
// TODO: implement fuzzification of a Neighborhood around the current active state
//-----------------------------------------------------------------------------
vector<double> World::fuzzificationOfNeighborhood(vector<int> values, vector<int> maxSizes, int neighborhoodSize) {
  vector<double> retvalue(statesNum, 0);
  return(retvalue);
}
//-----------------------------------------------------------------------------
// TODO: implement fuzzification of a Neighborhood around the current active state
//-----------------------------------------------------------------------------
vector<double> World::fuzzificationOfNeighborhood(vector<int> values, vector<int> maxSizes, vector<int> neighborhoodSize) {
  vector<double> retvalue(statesNum, 0);
  return(retvalue);
}
//-----------------------------------------------------------------------------
// At the moment, this function is able to fuzzificate state spaces built of
// up to two variables.
// TODO: make this function generic to be able to work with multivariate
// fuzzification of states.
//-----------------------------------------------------------------------------
vector<double> World::fuzzificationOfStateSpace(vector<int> values, vector<int> maxSizes) {
  vector<double> retvalue(statesNum, 0);
  vector<vector<double> > tmp_matrix;
  double ux = values[0]; double sigma_x = sigma;  double scope_minX = 0; unsigned int samples_x = maxSizes[0];  double resolution_x = 1;
  double uy = values[1]; double sigma_y = sigma;  double scope_minY = 0; unsigned int samples_y = maxSizes[1];  double resolution_y = 1;
  tmp_matrix = bump.bivariateGaussianDistribution(ux,uy,sigma_x,sigma_y,scope_minX,scope_minY,samples_x,samples_y,resolution_x,resolution_y);

  double accumulator = 0.0;
  for(unsigned int idr = 0; idr < substateSizes[1]; idr++) {
    for(unsigned int idc = 0; idc < substateSizes[0]; idc++) {
      int s = (idc) + (idr)*substateSizes[0];
      retvalue[s] = tmp_matrix[idr][idc];
      accumulator += retvalue[s];
    }
  }

  // State space normalization
  for (unsigned int idr = 0; idr < statesNum; idr++) {
  	retvalue[idr] /= accumulator;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int World::determineCurrentStateValue(void) {
  unsigned int retvalue = 0;

  retvalue += substateValues[0];
  for (unsigned int idr = 1; idr < substateNumber; idr++) {
    retvalue += substateValues[idr]*substateSizes[idr-1];
  }

  if (operationMode != _BATCH)
    exportRawSensoryValuesToFile(substateSensorValues);

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int World::determineSubstateValueOfVariable(unsigned int value) {
  unsigned int retvalue = 0;
  switch (value) {
  	case _VARIABLE_X_AXIS:
      // This will require some fancy functions to check sensor information
      // and then discretize the values accordingly
      retvalue = substateValues[value];
      substateSensorValues[value] = retvalue;
  		break;

  	case _VARIABLE_Y_AXIS:
      // This will require some fancy functions to check sensor information
      // and then discretize the values accordingly
      retvalue = substateValues[value];
      substateSensorValues[value] = retvalue;
  		break;

  	default:
      retvalue = 0;
  		break;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned int World::getNextActionFromUser(void) {
	string s;
	unsigned int retvalue = _STOCHASTIC_ACTION_SELECTION;
	bool finish = false;

  fprintf(stdout, "Please select an action:\n");
  fprintf(stdout, "   8 -> Move Forward\n");
  fprintf(stdout, "   9 -> Turn Right\n");
  fprintf(stdout, "   2 -> Move Backward\n");
  fprintf(stdout, "   7 -> Turn Left\n");
  fprintf(stdout, "   6 -> Move to the Right\n");
  fprintf(stdout, "   4 -> Move to the Left\n");
  fprintf(stdout, "   a -> Stochastic action selection\n");
  fprintf(stdout, "  finish -> to finish\n");
  fprintf(stdout, "  restart -> to restart\n");

	while(!finish) {
	  getline(cin, s);
    // Move Forward
		if(s == "8") {
		  retvalue = _MOVE_FORWARDS;
		  finish = true;
    // Turn right
		} else if(s == "9") {
		  retvalue = _TURN_RIGHT;
		  finish = true;
    // Move backwards
    } else if(s == "2") {
      retvalue = _MOVE_BACKWARDS;
      finish = true;
    // Turn left
    } else if(s == "7") {
      retvalue = _TURN_LEFT;
      finish = true;
    // Move to the left
    } else if(s == "4") {
      retvalue = _MOVE_LEFT;
      finish = true;
    // Move to the right
    } else if(s == "6") {
      retvalue = _MOVE_RIGHT;
      finish = true;
    } else if(s == "a") {
      retvalue = RNG.randi(actionsNum-1);
      userSelectedAction = _STOCHASTIC_ACTION_SELECTION;
      finish = true;
    } else if(s == "restart") {
      retvalue = RNG.randi(actionsNum-1);
      userSelectedAction = _RESTART_TRIAL;
      fprintf(stdout, "New position!!\n");
      finish = true;
    } else if(s == "finish") {
      retvalue = RNG.randi(actionsNum-1);
      userSelectedAction = _FINISH_LEARNING;
      fprintf(stdout, "LEARNING WILL BE FINISHED!!\n");
      finish = true;
    }
	}

	return(retvalue);
}
//*****************************************************************************
// World Class Implementation: END
//*****************************************************************************
