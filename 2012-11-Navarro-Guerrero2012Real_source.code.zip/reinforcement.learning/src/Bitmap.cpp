//*****************************************************************************
// Title: Bitmap.cpp
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: April 2012
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

//*****************************************************************************
// Libraries Declaration
#include "Bitmap.hpp"

//*****************************************************************************
// Global Variables Definition


//*****************************************************************************
// BitmapLite Class Implementation: BEGIN
//*****************************************************************************
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
BitmapLite::BitmapLite() {
  init();
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
BitmapLite::~BitmapLite() {
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void BitmapLite::init(void) {
}
//-----------------------------------------------------------------------------
// Create a gray-scale PNM file of size Buffer[idr] (height) * Buffer[idr][idc]
// (width) under the given filename. The input vector has to be normalized, i.e. contain values ranging [0,1]. On error the return value is false.
//-----------------------------------------------------------------------------
bool BitmapLite::saveRGBmapWeights(vector<vector<double> > Buffer, string fileName) {
  unsigned int width = Buffer[1].size();
  unsigned int height = Buffer.size();
  stringstream ss;

  // Header Definition
  ss << "P3" << std::endl;  // Portable graymap - ASCII
  ss << "# The P3 means colors are in ASCII, then WIDTH and HEIGHT" << std::endl;
  ss << width << " " << height << std::endl;
  ss << "# then 255 for max value, then RGB triplets" << std::endl;
  ss << "255" << std::endl;

  int rgbValue = 0;
  vector<unsigned int> hsv(3,0);
  vector<unsigned int> rgb(3,0);
  for(unsigned int idr = 0; idr < height; idr++) {
    for(unsigned int idc = 0; idc < width; idc++) {
      if (Buffer[idr][idc] > 0) {
        rgbValue = 255-lrint(Buffer[idr][idc]*255);
        ss << rgbValue << " " << rgbValue << " " << "255" << " ";
      } else if (Buffer[idr][idc] == 0) {
        rgbValue = 255;
        ss << rgbValue << " " << rgbValue << " " << rgbValue << " ";
      } else {
        rgbValue = 255-abs(lrint(Buffer[idr][idc]*255));
        ss << "255" << " " << rgbValue << " " << rgbValue << " ";
      }
    }
    ss << std::endl;
  }

  ofstream pFile(fileName.c_str());
  pFile << ss.str().c_str();
  pFile.close();

  return(true);
}
//-----------------------------------------------------------------------------
// Create a gray-scale PNM file of size Buffer[idr] (height) * Buffer[idr][idc]
// (width) under the given filename. The input vector has to be normalized, i.e. contain values ranging [0,1]. On error the return value is false.
//-----------------------------------------------------------------------------
bool BitmapLite::saveGraymap(vector<vector<double> > Buffer, string fileName) {
  unsigned int width = Buffer[1].size();
  unsigned int height = Buffer.size();
  stringstream ss;

  // Header Definition
  ss << "P2" << std::endl;  // Portable graymap - ASCII
  ss << "# Widht - Height" << std::endl;
  ss << width << " " << height << std::endl;
  ss << "# Pixel Max value" << std::endl;
  ss << "255" << std::endl;

  for(unsigned int idr = 0; idr < height; idr++) {
    for(unsigned int idc = 0; idc < width; idc++) {
      if(Buffer[idr][idc] == 1) {
        ss << 255 << " ";
      } else {
        ss << lrint(Buffer[idr][idc]*255) << " ";
      }
    }
    ss << std::endl;
  }

  ofstream pFile(fileName.c_str());
  pFile << ss.str().c_str();
  pFile.close();

  return(true);
}
//-----------------------------------------------------------------------------
// Create a gray-scale PNM file of size Buffer[idr] (height) * Buffer[idr][idc]
// (width) under the given filename. The input vector has to be normalized, i.e. contain values ranging [0,1]. On error the return value is false.
//-----------------------------------------------------------------------------
bool BitmapLite::saveGraymapInverted(vector<vector<double> > Buffer, string fileName) {
  unsigned int width = Buffer[1].size();
  unsigned int height = Buffer.size();
  stringstream ss;

  // Header Definition
  ss << "P2" << std::endl;  // Portable graymap - ASCII
  ss << "# Widht - Height" << std::endl;
  ss << width << " " << height << std::endl;
  ss << "# Pixel Max value" << std::endl;
  ss << "255" << std::endl;

  int darker = 0;

  for(unsigned int idr = 0; idr < height; idr++) {
    for(unsigned int idc = 0; idc < width; idc++) {
      if(Buffer[idr][idc] == 0) {
        ss << 255 << " ";
      } else if((lrint(Buffer[idr][idc]*255)) >= (255-darker)) {
        ss << 255-lrint(Buffer[idr][idc]*255) << " ";
      } else {
        ss << 255-lrint(Buffer[idr][idc]*255)-darker << " ";
      }
    }
    ss << std::endl;
  }

  ofstream pFile(fileName.c_str());
  pFile << ss.str().c_str();
  pFile.close();

  return(true);
}
//-----------------------------------------------------------------------------
// This function does not work
//-----------------------------------------------------------------------------
vector<unsigned int> BitmapLite::HSVtoRGB(vector<unsigned int> __hsv) {
  vector<unsigned int> __rgb(3,0);

  double __chroma = __hsv[_SATURATION]* __hsv[_VALUE] / 10000.0;
  double __Hprime = __hsv[_HUE] / 60.0;
  double __X = __chroma*(1-abs(fmod(__Hprime,2) - 1));

  double red = 0;
  double green = 0;
  double blue = 0;
  if ((0 <= __Hprime) && (__Hprime < 1)) {
    red = __chroma;
    green = __X;
    blue = 0;
  } else if ((1 <= __Hprime) && (__Hprime < 2)) {
    red = __X;
    green = __chroma;
    blue = 0;
  } else if ((2 <= __Hprime) && (__Hprime < 3)) {
    red = 0;
    green = __chroma;
    blue = __X;
  } else if ((3 <= __Hprime) && (__Hprime < 4)) {
    red = 0;
    green = __X;
    blue = __chroma;
  } else if ((4 <= __Hprime) && (__Hprime < 5)) {
    red = __X;
    green = 0;
    blue = __chroma;
  } else if ((5 <= __Hprime) && (__Hprime < 6)) {
    red = __chroma;
    green = 0;
    blue = __X;
  }

  double __m = (__hsv[_VALUE]/100.0) - __chroma;
  __rgb[_RED] =  lrint(ceil((red + __m) * 255));
  __rgb[_GREEN] = lrint(ceil((green + __m) * 255));
  __rgb[_BLUE] = lrint(ceil((blue + __m) * 255));

  return(__rgb);
}
//-----------------------------------------------------------------------------
// This function does not work
//-----------------------------------------------------------------------------
vector<unsigned int> BitmapLite::HSVtoRGB(unsigned int __h,unsigned int __s,unsigned int __v) {
  vector<unsigned int> __rgb(3,0);

  double __chroma = __s * __v / 10000.0;
  double __Hprime = __h / 60.0;
  double __X = __chroma*(1-abs(fmod(__Hprime,2) - 1));

  double red = 0;
  double green = 0;
  double blue = 0;
  if ((0 <= __Hprime) && (__Hprime < 1)) {
    red = __chroma;
    green = __X;
    blue = 0;
  } else if ((1 <= __Hprime) && (__Hprime < 2)) {
    red = __X;
    green = __chroma;
    blue = 0;
  } else if ((2 <= __Hprime) && (__Hprime < 3)) {
    red = 0;
    green = __chroma;
    blue = __X;
  } else if ((3 <= __Hprime) && (__Hprime < 4)) {
    red = 0;
    green = __X;
    blue = __chroma;
  } else if ((4 <= __Hprime) && (__Hprime < 5)) {
    red = __X;
    green = 0;
    blue = __chroma;
  } else if ((5 <= __Hprime) && (__Hprime < 6)) {
    red = __chroma;
    green = 0;
    blue = __X;
  }

  double __m = (__v/100.0) - __chroma;
  __rgb[_RED] =  lrint(ceil((red + __m) * 255));
  __rgb[_GREEN] = lrint(ceil((green + __m) * 255));
  __rgb[_BLUE] = lrint(ceil((blue + __m) * 255));

  return(__rgb);
}
//*****************************************************************************
// BitmapLite Class Implementation: END
//*****************************************************************************
