//*****************************************************************************
// Title: Bitmap.hpp
//
// Version: 0.1
// Copyright (C) 2012 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: April 2012
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: April 2012
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

#ifndef __BITMAP_LITE_H__
#define __BITMAP_LITE_H__

//*****************************************************************************
// Libraries Declaration
//-----------------------------------------------------------------------------
// C/C++ libraries
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <ctime>

//-----------------------------------------------------------------------------
// Specific tool libraries

//-----------------------------------------------------------------------------
// Own Libraries

//*****************************************************************************
// Global Variables Definition
using namespace std;

enum _RGB_ARRAY_INDEXING_ {
  _RED = 0,
  _GREEN,
  _BLUE,
};

enum _HSV_ARRAY_INDEXING_ {
  _HUE = 0,
  _SATURATION,
  _VALUE,
};

//*****************************************************************************
/**
 * BitmapLite Class Declaration
 */
//*****************************************************************************
class BitmapLite {
  public:
    BitmapLite();
    ~BitmapLite();

    // For values ranging [0,1]. Small values are mapped with darker colors,
    // while large values are mapped with lighter colors
    bool saveGraymap(vector<vector<double> > Buffer, string fileName);
    // For values ranging [0,1]. Small values are mapped with lighter colors,
    // while large values are mapped with darker colors
    bool saveGraymapInverted(vector<vector<double> > Buffer, string fileName);

    // For values ranging [-1,1]. Values close to zero are mapped with lighter
    // colors, while values with large magnitude are represented with darker
    // colors. Positive values are represented with gray color, while negative
    // values are represented with blue colors and zeros as white.
    bool saveRGBmapWeights(vector<vector<double> > Buffer, string fileName);

    // all values are integers
    // RGB in [0,255]
    // H in [0,360]
    // S and V in [0,100]
    vector<unsigned int> HSVtoRGB(vector<unsigned int> __hsv);
    vector<unsigned int> HSVtoRGB(unsigned int __h,unsigned int __s,unsigned int __v);

  protected:

  private:
    void init(void);

};
//*****************************************************************************
// BitmapLite Class Declaration: END
//*****************************************************************************

#endif  // __BITMAP_LITE_H__
