//*****************************************************************************
// Title: RandomNumberGenerators.cpp
// Description:
//
// Version: 0.1
// Copyright (C) 2011 Nicolas Navarro-Guerrero
// Contact: nicolas.navarro.guerrero@gmail.com
// Created in: October 2011
// Last Modification by: Nicolas Navarro-Guerrero
// Last Modification in: November 2011
//
// DISCLAIMER:
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see http://www.gnu.org/licenses/.
//
// DISTRIBUTION:
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or (at
// your option) any later version.
//
// In short, GPL allows free use and free modification, but any derivative
// work must be distributed under GPL license too (copyleft requirement).
//*****************************************************************************

//*****************************************************************************
// Libraries Declaration
#include "RandomNumberGenerators.hpp"

//*****************************************************************************
// Global Variables Definition


//*****************************************************************************
// RNG = RANDOM NUMBER GENERATORS Class Implementation: BEGIN
//*****************************************************************************
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
RandomNumberGenerators::RandomNumberGenerators() {
  _RNG_METHOD_ = _RNG_MERSENNE_TWISTER;

  init();
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
RandomNumberGenerators::~RandomNumberGenerators() {
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void RandomNumberGenerators::init(void) {
//  myseed = 1314174611;
  myseed = time(NULL);
  fprintf(stdout, "RANDOM NUMBER GENERATOR: I AM USING THE FOLLOWING SEED: %ld\n", myseed);

  srand(myseed); // set seed for random function
  init_MERSENNE_TWISTER(rand());
  init_MOTHER_OF_ALL(rand());
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double RandomNumberGenerators::randd(void) {
  return(randomDouble());
}
//-----------------------------------------------------------------------------
// TODO: randd(n) - Test thoroughly please
//-----------------------------------------------------------------------------
vector<vector<double> > RandomNumberGenerators::randd(unsigned int n) {
  vector<vector<double> > result;
  vector<double> tmp_row(n, 0.0);
  for (unsigned int idr = 0; idr < n; idr++) {
  	for (unsigned int idc = 0; idc < n; idc++) {
      tmp_row[idc] = randomDouble();
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: randd(m,n) - test thoroughly please
//-----------------------------------------------------------------------------
vector<vector<double> > RandomNumberGenerators::randd(
      unsigned int m, unsigned int n) {
  vector<vector<double> > result;
  vector<double> tmp_row(n, 0.0);
  for (unsigned int idr = 0; idr < m; idr++) {
  	for (unsigned int idc = 0; idc < n; idc++) {
      tmp_row[idc] = randomDouble();
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: sprand(m,n,density) - test thoroughly please
// Sparse uniformly distributed random matrix (0 <= density <= 1)
//-----------------------------------------------------------------------------
vector<vector<double> > RandomNumberGenerators::sprand(
      unsigned int m, unsigned int n, double density) {
  vector<vector<double> > result;
  vector<double> tmp_row;
  for (unsigned int idr = 0; idr < m; idr++) {
    tmp_row.clear();
    tmp_row.assign(n, 0.0);
  	for (unsigned int idc = 0; idc < n; idc++) {
  	  if (randomDouble() <= density) {
  	  	do {
  	  		tmp_row[idc] = randomDouble();
  	  	} while (tmp_row[idc] == 0);
  	  }
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: sprandn(m,n,density) - Implement and test thoroughly please
// Sparse normally distributed random matrix (0 <= density <= 1)
//-----------------------------------------------------------------------------
vector<vector<double> > RandomNumberGenerators::sprandn(
      unsigned int m, unsigned int n, double density) {
  vector<vector<double> > result;
  ;
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: sprandsym(n, density) - Implement and test thoroughly please
// Sparse symmetric random matrix. Returns a symmetric random, n-by-n,
// sparse matrix with approximately density*n*n nonzeros. each entry is a
// normally distributed random sample, and (0 <= density <= 1)
//-----------------------------------------------------------------------------
vector<vector<double> > RandomNumberGenerators::sprandsym(
      unsigned int n, double density) {
  vector<vector<double> > result;
  ;
  return(result);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
int RandomNumberGenerators::randi(unsigned int imax) {
  return(randomInteger(0, imax));
}
//-----------------------------------------------------------------------------
// TODO: randi(imax, n) - test thoroughly please
//-----------------------------------------------------------------------------
vector<vector<int> > RandomNumberGenerators::randi(
      unsigned int imax, unsigned int n) {
  vector<vector<int> > result;
  vector<int> tmp_row(n, 0);
  for (unsigned int idr = 0; idr < n; idr++) {
  	for (unsigned int idc = 0; idc < n; idc++) {
      tmp_row[idc] = randomInteger(0, imax);
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: randi(imin, imax, n) - test thoroughly please
//-----------------------------------------------------------------------------
vector<vector<int> > RandomNumberGenerators::randi(
      int imin, int imax, unsigned int n) {
  vector<vector<int> > result;
  vector<int> tmp_row(n, 0);
  for (unsigned int idr = 0; idr < n; idr++) {
  	for (unsigned int idc = 0; idc < n; idc++) {
      tmp_row[idc] = randomInteger(imin, imax);
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: randi(imax, m, n) - test thoroughly please
//-----------------------------------------------------------------------------
vector<vector<int> > RandomNumberGenerators::randi(
      unsigned int imax, unsigned int m, unsigned int n) {
  vector<vector<int> > result;
  vector<int> tmp_row(n, 0);
  for (unsigned int idr = 0; idr < m; idr++) {
  	for (unsigned int idc = 0; idc < n; idc++) {
      tmp_row[idc] = randomInteger(0, imax);
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: randi(imin, imax, m, n) - test thoroughly please
//-----------------------------------------------------------------------------
vector<vector<int> > RandomNumberGenerators::randi(
      int imin, int imax, unsigned int m, unsigned int n) {
  vector<vector<int> > result;
  vector<int> tmp_row(n, 0);
  for (unsigned int idr = 0; idr < m; idr++) {
  	for (unsigned int idc = 0; idc < n; idc++) {
      tmp_row[idc] = randomInteger(imin, imax);
  	}
  	result.push_back(tmp_row);
  }
  return(result);
}
//-----------------------------------------------------------------------------
// TODO: MERSENNE_TWISTER and MOTHER_OF_ALL give the same results. at least for
//  double generation ???
//-----------------------------------------------------------------------------
void RandomNumberGenerators::init_MERSENNE_TWISTER(uint32_t value) {
  // Seed generator
  const uint32_t factor = 1812433253UL;
  mt[0]= value;
  for(mti = 1; mti < MERS_N; mti++) {
    mt[mti] = (factor * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti);
  }

  // Randomize some more
  for (unsigned int i = 0; i < 37; i++) randomWord_MERSENNE_TWISTER();
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void RandomNumberGenerators::init_MOTHER_OF_ALL(uint32_t value) {
  uint32_t s = value;
  // make random numbers and put them into the buffer
  for (unsigned int i = 0; i < 5; i++) {
    s = s * 29943829 - 1;
    MOAState[i] = s;
  }

  // randomize some more
  for(unsigned int i = 0; i < 19; i++) randomWord_MOTHER_OF_ALL();
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void RandomNumberGenerators::setSeed(unsigned long int value) {
  myseed = value;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void RandomNumberGenerators::setRandomGeneratorMethod(char value) {
  _RNG_METHOD_ = value;
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
unsigned long int RandomNumberGenerators::getSeed(void) {
  return(myseed);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
char RandomNumberGenerators::getRandomGeneratorMethod(void) {
  return(_RNG_METHOD_);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
bool RandomNumberGenerators::randomBoolean(void) {
  bool retvalue = false;
  uint32_t tmp_value = 0;

  switch(_RNG_METHOD_) {
    case _RNG_STANDARD:
      tmp_value = randomWord_STANDARD();
      break;

    case _RNG_MERSENNE_TWISTER:
      init_MERSENNE_TWISTER(randomWord_STANDARD());
      tmp_value = randomWord_MERSENNE_TWISTER();
      break;

    case _RNG_MOTHER_OF_ALL:
      init_MOTHER_OF_ALL(randomWord_STANDARD());
      tmp_value = randomWord_MOTHER_OF_ALL();
      break;

    default:
      tmp_value = randomWord_STANDARD();
      break;
  }
  if ((tmp_value & 0x01) == 0x01) {
    retvalue = true;
  } else {
    retvalue = false;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
uint32_t RandomNumberGenerators::randomWord(void) {
  uint32_t retvalue = 0;

  switch(_RNG_METHOD_) {
    case _RNG_STANDARD:
      retvalue = randomWord_STANDARD();
      break;

    case _RNG_MERSENNE_TWISTER:
      init_MERSENNE_TWISTER(randomWord_STANDARD());
      retvalue = randomWord_MERSENNE_TWISTER();
      break;

    case _RNG_MOTHER_OF_ALL:
      init_MOTHER_OF_ALL(randomWord_STANDARD());
      retvalue = randomWord_MOTHER_OF_ALL();
      break;

    default:
      retvalue = randomWord_STANDARD();
      break;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
uint32_t RandomNumberGenerators::randomWord_STANDARD(void) {
  uint32_t retvalue = 0;
  long int range = lround(pow(10.0, 9.0));

  for (unsigned int idr = 0; idr < 5; idr++) {
    retvalue = retvalue << 8;
    retvalue = (rand() % range+1);
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
uint32_t RandomNumberGenerators::randomWord_MERSENNE_TWISTER(void) {
  uint32_t retvalue;  // Generate 32 random bits

  if(mti >= MERS_N) {
    // Generate MERS_N words at one time
    const uint32_t LOWER_MASK = (1LU << MERS_R) - 1; // Lower MERS_R bits
    const uint32_t UPPER_MASK = 0xFFFFFFFF << MERS_R;// Upper (32 - MERS_R) bits
    static const uint32_t mag01[2] = {0, MERS_A};

    unsigned int kk;
    for(kk = 0; kk < MERS_N - MERS_M; kk++) {
      retvalue = (mt[kk] & UPPER_MASK) | (mt[kk+1] & LOWER_MASK);
      mt[kk] = mt[kk+MERS_M] ^ (retvalue >> 1) ^ mag01[retvalue & 1];
    }

    for(; kk < MERS_N - 1; kk++) {
      retvalue = (mt[kk] & UPPER_MASK) | (mt[kk+1] & LOWER_MASK);
      mt[kk] = mt[kk+(MERS_M-MERS_N)] ^ (retvalue >> 1) ^ mag01[retvalue & 1];
    }

    retvalue = (mt[MERS_N-1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
    mt[MERS_N-1] = mt[MERS_M-1] ^ (retvalue >> 1) ^ mag01[retvalue & 1];
    mti = 0;
  }
  retvalue = mt[mti++];

  // Tempering (May be omitted):
  retvalue ^=  retvalue >> MERS_U;
  retvalue ^= (retvalue << MERS_S) & MERS_B;
  retvalue ^= (retvalue << MERS_T) & MERS_C;
  retvalue ^=  retvalue >> MERS_L;

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
uint32_t RandomNumberGenerators::randomWord_MOTHER_OF_ALL(void) {
  uint64_t sum;
  sum = (uint64_t)2111111111UL * (uint64_t)MOAState[3] +
        (uint64_t)1492 * (uint64_t)(MOAState[2]) +
        (uint64_t)1776 * (uint64_t)(MOAState[1]) +
        (uint64_t)5115 * (uint64_t)(MOAState[0]) +
        (uint64_t)MOAState[4];

  MOAState[3] = MOAState[2];
  MOAState[2] = MOAState[1];
  MOAState[1] = MOAState[0];

  MOAState[4] = (uint32_t)(sum >> 32); // Carry
  MOAState[0] = (uint32_t)sum;         // Low 32 bits of sum

  uint32_t retvalue = MOAState[0];
  return(retvalue);
}

//-----------------------------------------------------------------------------
// TODO: randomDouble() - Test thoroughly please
//-----------------------------------------------------------------------------
double RandomNumberGenerators::randomDouble(void) {
  double retvalue = 0.0;

  switch(_RNG_METHOD_) {
    case _RNG_STANDARD:
      retvalue = randomDouble_STANDARD();
      break;

    case _RNG_MERSENNE_TWISTER:
      init_MERSENNE_TWISTER(randomWord_STANDARD()*randomWord_MERSENNE_TWISTER());
      retvalue = randomDouble_MERSENNE_TWISTER();
      break;

    case _RNG_MOTHER_OF_ALL:
      init_MOTHER_OF_ALL(randomWord_STANDARD()*randomWord_MOTHER_OF_ALL());
      retvalue = randomDouble_MOTHER_OF_ALL();
      break;

    default:
      retvalue = randomDouble_STANDARD();
      break;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double RandomNumberGenerators::randomDouble_STANDARD(void) {
  double retvalue = 0.0;
  // Pseudo-Random double into range of [0, 1] with 9 digits of precision.
  long int range = lround(pow(10.0, 9.0));
  double precision = 1.0/range;
  retvalue = (rand() % range+1) * precision;
  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double RandomNumberGenerators::randomDouble_MERSENNE_TWISTER(void) {
  double retvalue = 0.0;
  // Output random float number in the interval 0 <= x < 1. Multiply by 2^(-32)
  retvalue = (double)randomWord_MERSENNE_TWISTER() * (1./(65536.*65536.));
  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
double RandomNumberGenerators::randomDouble_MOTHER_OF_ALL(void) {
  double retvalue = 0.0;
  // Pseudo-Random double in the  range [0, 1[ with 32 bits of resolution
  retvalue = (double)randomWord_MOTHER_OF_ALL() * (1./(65536.*65536.));
  return(retvalue);
}

//-----------------------------------------------------------------------------
// TODO: randomInteger(min, max) - Test thoroughly please
//-----------------------------------------------------------------------------
int RandomNumberGenerators::randomInteger(int min, int max) {
  int retvalue = 0;

  switch(_RNG_METHOD_) {
    case _RNG_STANDARD:
      retvalue = randomInteger_STANDARD(min, max);
      break;

    case _RNG_MERSENNE_TWISTER:
      init_MERSENNE_TWISTER(randomWord_STANDARD()*randomWord_MERSENNE_TWISTER());
      retvalue = randomInteger_MERSENNE_TWISTER(min, max);
      break;

    case _RNG_MOTHER_OF_ALL:
      init_MOTHER_OF_ALL(randomWord_STANDARD()*randomWord_MOTHER_OF_ALL());
      retvalue = randomInteger_MOTHER_OF_ALL(min, max);
      break;

    default:
      retvalue = randomInteger_STANDARD(min, max);
      break;
  }

  return(retvalue);
}
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
int RandomNumberGenerators::randomInteger_STANDARD(int min, int max) {
  int retvalue = 0;
  retvalue = (rand() % abs(max+1)) + min;
  return(retvalue);
}
//-----------------------------------------------------------------------------
// TODO: randomInteger_MERSENNE_TWISTER(min, max) - Test thoroughly please
//-----------------------------------------------------------------------------
int RandomNumberGenerators::randomInteger_MERSENNE_TWISTER(int min, int max) {
  int retvalue = 0;

  // Output random integer in the interval min <= x <= max
  // Relative error on frequencies < 2^-32
  if(max <= min) {
    if(max == min)
      return min;
    else
      return 0x80000000;
  }

  // Multiply interval with random and truncate
  retvalue = int((double)(uint32_t)(max - min + 1) * randomDouble_MERSENNE_TWISTER() + min);

  if(retvalue > max)  retvalue = max;
  return(retvalue);
}
//-----------------------------------------------------------------------------
// TODO: randomInteger_MOTHER_OF_ALL(min, max) - Test thoroughly please
//-----------------------------------------------------------------------------
int RandomNumberGenerators::randomInteger_MOTHER_OF_ALL(int min, int max) {
  // Output random integer in the interval min <= x <= max
  // Relative error on frequencies < 2^-32
  if(max <= min) {
    if(max == min)
      return min;
    else
      return 0x80000000;
  }
  // Assume 64 bit integers supported. Use multiply and shift method
  uint32_t interval;    // Length of interval
  uint64_t longran;     // Random bits * interval
  uint32_t iran;        // Longran / 2^32

  interval = (uint32_t)(max - min + 1);
  longran  = (uint64_t)randomWord_MOTHER_OF_ALL() * interval;
  iran = (uint32_t)(longran >> 32);
  // Convert back to signed and return result
  int retvalue = (int32_t)iran + min;
  return(retvalue);
}
//*****************************************************************************
// RNG = RANDOM NUMBER GENERATORS Class Implementation: END
//*****************************************************************************
